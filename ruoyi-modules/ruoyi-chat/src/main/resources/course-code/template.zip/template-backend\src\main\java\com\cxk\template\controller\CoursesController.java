package com.cxk.template.controller;

import com.cxk.template.domain.entity.CoursesEntity;
import com.cxk.template.service.CoursesService;
import com.cxk.template.domain.vo.CoursesVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
import com.cxk.template.common.model.Result;
import com.cxk.template.common.model.PageResult;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import com.cxk.template.common.model.IdListForm;

/**
 * 课程表Controller层
 *
 * @author 校园小助手 2026/06/03
 */
@Slf4j
@RestController
@RequestMapping("/courses")
public class CoursesController {

    @Resource
    private CoursesService coursesService;


    /**
     * 新增课程表
     */
    @PostMapping("/save")
    @Operation(summary = "保存课程表数据}")
    public Result<Void> saveCourses( @RequestBody CoursesEntity coursesEntity) {
        coursesService.saveCourses(coursesEntity);
        return Result.success();
    }

    /**
     * 删除课程表
     */
    @PostMapping("/remove")
    @Operation(summary = "删除课程表数据}")
    public Result<Void> removeCoursess( @RequestBody IdListForm idListForm) {
        List<Long> ids = idListForm.getIds();
        coursesService.removeCoursess(ids);
        return Result.success();
    }

    /**
     * 修改课程表
     */
    @PostMapping("/update")
    @Operation(summary = "修改课程表数据}")
    public Result<Void> updateCourses(@RequestBody CoursesEntity coursesEntity) {
        coursesService.updateCourses(coursesEntity);
        return Result.success();
    }

    /**
      * 根据ID查询课程表
      */
    @GetMapping("/get")
    @Operation(summary = "根据ID查询课程表数据}")
    public Result<CoursesEntity> getCoursesById(@RequestParam Long id) {
        CoursesEntity coursesEntity = coursesService.getCoursesById(id);
        return Result.success(coursesEntity);
    }

    /**
     * 查看所有课程表
     */
    @PostMapping("/getAll")
    @Operation(summary = "查看所有课程表数据}")
    public Result<List<CoursesEntity>> getAllCoursess(@RequestBody CoursesVO coursesVO) {
        List<CoursesEntity> coursesEntityList = coursesService.getAllCoursess(coursesVO);
        return Result.success(coursesEntityList);
    }

    /**
     * 分页查询课程表
     */
    @PostMapping("/getPage")
    @Operation(summary = "分页查询课程表数据}")
    public Result<PageResult<CoursesEntity>> getCoursesByPage( @RequestBody CoursesVO coursesVO) {
        PageResult<CoursesEntity> pageResult = coursesService.getCoursesByPage(coursesVO);
        return Result.success(pageResult);
    }
}
