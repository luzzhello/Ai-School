package com.cxk.template.domain.vo;

import lombok.Data;
import lombok.experimental.Accessors;
import com.cxk.template.common.model.PageParam;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

/**
 * 学生表展示类
 *
 * @author 校园小助手 2026/06/03
 */
@Data
@Accessors(chain = true)
public class StudentsVO extends PageParam {

/**
 * 学号
 */
    @JsonSerialize(using = ToStringSerializer.class)
private Long id;

/**
 * 姓名
 */
private String name;

/**
 * 年龄
 */
    @JsonSerialize(using = ToStringSerializer.class)
private Long age;

/**
 * 邮箱
 */
private String email;

}
