import {DefaultFooter} from '@ant-design/pro-components';
import React from 'react';

const Footer: React.FC = () => {
  return (
    <DefaultFooter
      copyright={
        <>
          2024 ikun工作室
        </> as any
      }
      style={{
        background: 'none',
      }}
      links={[
        {
          key: "备案号111-1",
          title: "备案号111-1",
          href: 'https://beian.miit.gov.cn/',
          blankTarget: true,
        },
      ]}
    />
  );
};

export default Footer;
