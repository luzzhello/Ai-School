代码生成使用说明

前端项目：
# template-front

前端模版框架

使用步骤：

1. 后端根据数据库生成对应的代码
2. 把前端代码拷贝到对应的目录中
3. 前端设置对应的路由在`config/router.ts`中配置
4. 启动后端项目，确保可以访问到后端的swagger文档，需要在`config/config.ts`中配置后端的文档地址
5. 前端运行`npm run openapi`来生成对应的api文件

进入 template-frontend
运行：
```shell
npm install
npm run serve
```


后端项目：

进入 template-backend
运行：
```shell
mvn clean install
```

后端模版框架

+ 初始账号：1@qq.com
+ 初始密码：123456
+ swagger文档：http://localhost:10000/template/doc.html#/home
