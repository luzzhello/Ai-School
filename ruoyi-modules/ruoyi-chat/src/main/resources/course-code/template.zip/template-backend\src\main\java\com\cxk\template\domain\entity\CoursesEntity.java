package com.cxk.template.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;
import lombok.EqualsAndHashCode;

/**
 * 课程表实体类
 * <p>请不要手动修改该类</p>
 *
 * @author 校园小助手 2026/06/03
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
@TableName("Courses")
public class CoursesEntity extends Model<CoursesEntity> {

    /**
     * 课程ID
     */
    @TableId(value ="id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * 课程名
     */
    @TableField("course_name")
    private String courseName;

    /**
     * 学分
     */
    @TableField("credits")
    private Long credits;

}
