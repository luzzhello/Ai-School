package com.cxk.template.common.utils;

import com.cxk.template.common.config.FileStorageConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class FileStorageUtils {
    @Autowired
    private FileStorageConfig fileStorageConfig;

    /**
     * 应用启动时初始化上传目录
     */
    @PostConstruct
    public void initializeStorage() {
        init();
        log.info("文件存储服务初始化完成，上传目录: {}",
                Paths.get(fileStorageConfig.getUploadDir()).toAbsolutePath());
    }

    /**
     * 初始化上传目录
     */
    public void init() {
        try {
            Path uploadPath = Paths.get(fileStorageConfig.getUploadDir());
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
                log.info("创建文件上传目录: {}", uploadPath.toAbsolutePath());
            }
        } catch (IOException e) {
            log.error("无法初始化上传目录: {}", e.getMessage());
            throw new RuntimeException("无法初始化上传目录", e);
        }
    }

    /**
     * 获取文件列表
     */
    public List<String> listObjects() {
        List<String> list = new ArrayList<>();
        try {
            Path uploadPath = Paths.get(fileStorageConfig.getUploadDir());
            if (Files.exists(uploadPath)) {
                Files.walk(uploadPath, 1)
                        .filter(path -> !path.equals(uploadPath))
                        .forEach(path -> {
                            String fileName = path.getFileName().toString();
                            log.info("文件: {}, 大小: {}", fileName, getFileSize(path));
                            list.add(fileName);
                        });
            }
        } catch (Exception e) {
            log.error("获取文件列表错误: {}", e.getMessage());
        }
        return list;
    }

    /**
     * 删除文件
     */
    public void deleteObject(String objectName) {
        try {
            Path filePath = Paths.get(fileStorageConfig.getUploadDir(), objectName);
            if (Files.exists(filePath)) {
                Files.delete(filePath);
                log.info("文件已删除: {}", objectName);
            } else {
                log.warn("文件不存在: {}", objectName);
            }
        } catch (Exception e) {
            log.error("删除文件错误: {}", e.getMessage());
        }
    }

    /**
     * 上传文件流
     */
    public void uploadObject(InputStream is, String fileName, String contentType) {
        try {
            init();
            String uniqueFileName = generateUniqueFileName(fileName);
            Path targetPath = Paths.get(fileStorageConfig.getUploadDir(), uniqueFileName);
            Files.copy(is, targetPath);
            is.close();
            log.info("文件已上传: {}", uniqueFileName);
        } catch (Exception e) {
            log.error("上传文件错误: {}", e.getMessage());
        }
    }

    /**
     * 上传MultipartFile文件
     */
    public String uploadFile(MultipartFile file) {
        try {
            init();
            String originalFilename = file.getOriginalFilename();
            String uniqueFileName = generateUniqueFileName(originalFilename);
            Path targetPath = Paths.get(fileStorageConfig.getUploadDir(), uniqueFileName);
            Files.copy(file.getInputStream(), targetPath);
            log.info("文件已上传: {}", uniqueFileName);
            return uniqueFileName;
        } catch (Exception e) {
            log.error("上传文件错误: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 获取文件访问URL
     */
    public String getObjectUrl(String objectName) {
        try {
            Path filePath = Paths.get(fileStorageConfig.getUploadDir(), objectName);
            if (Files.exists(filePath)) {
                // 对文件名进行URL编码，确保特殊字符正确解析
                String encodedFileName = URLEncoder.encode(objectName, StandardCharsets.UTF_8.toString())
                        .replace("+", "%20");

                // 构建完整的URL路径，包含服务器上下文路径
                String contextPath = "/template"; // 从application.properties中的server.servlet.context-path获取
                return contextPath + fileStorageConfig.getBaseUrl() + "/" + encodedFileName;
            }
        } catch (Exception e) {
            log.error("获取文件URL错误: {}", e.getMessage());
        }
        return "";
    }

    /**
     * 获取文件输入流
     */
    public InputStream getObject(String objectName) {
        try {
            Path filePath = Paths.get(fileStorageConfig.getUploadDir(), objectName);
            if (Files.exists(filePath)) {
                return new FileInputStream(filePath.toFile());
            }
        } catch (Exception e) {
            log.error("获取文件错误: {}", e.getMessage());
        }
        return null;
    }

    /**
     * 生成唯一文件名
     */
    private String generateUniqueFileName(String originalFilename) {
        if (originalFilename == null) {
            return UUID.randomUUID().toString();
        }

        String extension = "";
        int lastDotIndex = originalFilename.lastIndexOf('.');
        if (lastDotIndex > 0) {
            extension = originalFilename.substring(lastDotIndex);
        }

        return UUID.randomUUID().toString() + extension;
    }

    /**
     * 获取文件大小
     */
    private String getFileSize(Path path) {
        try {
            long bytes = Files.size(path);
            if (bytes < 1024) {
                return bytes + " B";
            } else if (bytes < 1024 * 1024) {
                return String.format("%.2f KB", bytes / 1024.0);
            } else if (bytes < 1024 * 1024 * 1024) {
                return String.format("%.2f MB", bytes / (1024.0 * 1024));
            } else {
                return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
            }
        } catch (IOException e) {
            return "未知大小";
        }
    }
}