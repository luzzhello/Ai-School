package com.cxk.template.common.exception;


import com.cxk.template.common.model.Code;

/**
 * 抛异常工具类
 */
public class ThrowUtils {

    /**
     * 条件成立则抛异常
     *
     * @param condition
     * @param runtimeException
     */
    public static void throwIf(boolean condition, RuntimeException runtimeException) {
        if (condition) {
            throw runtimeException;
        }
    }

    /**
     * 条件成立则抛异常
     *
     * @param condition
     * @param Code
     */
    public static void throwIf(boolean condition, Code Code) {
        throwIf(condition, new BusinessException(Code));
    }

    /**
     * 条件成立则抛异常
     *
     * @param condition
     * @param Code
     * @param message
     */
    public static void throwIf(boolean condition, Code Code, String message) {
        throwIf(condition, new BusinessException(Code, message));
    }

    public static void throwIf(boolean condition, String message) {
        throwIf(condition, new BusinessException(Code.SYSTEM_ERROR, message));
    }
}
