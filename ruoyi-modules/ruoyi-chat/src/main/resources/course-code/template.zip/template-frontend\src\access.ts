/**
 * @see https://umijs.org/docs/max/access#access
 * */
export default function access(initialState: { currentUser?: API.UserVO } | undefined) {
  const {currentUser} = initialState ?? {};
  return {
    noLogin: initialState?.currentUser === null,
    isLogin: initialState?.currentUser !== null,
    canAdmin: currentUser && currentUser.userRole === 'admin',
    canUser: currentUser && currentUser.userRole === 'user',
    canAdminOrUser: currentUser && (currentUser.userRole === 'admin' || currentUser.userRole === 'user'),
  };
}
