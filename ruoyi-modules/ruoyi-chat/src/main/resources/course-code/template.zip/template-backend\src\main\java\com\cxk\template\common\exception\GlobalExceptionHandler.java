package com.cxk.template.common.exception;

import cn.dev33.satoken.exception.NotLoginException;
import cn.dev33.satoken.exception.SaTokenException;
import com.cxk.template.common.model.Code;
import com.cxk.template.common.model.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理器
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public Result<?> businessExceptionHandler(BusinessException e) {
        log.error("BusinessException", e);
        return Result.error(e.getCode(), e.getMessage());
    }

    /**
     * validation参数校验异常
     */
    @ExceptionHandler(value = {MethodArgumentNotValidException.class, BindException.class})
    public Result<?> bindException(BindException e) {
        StringBuilder errorMsg = new StringBuilder();
        e.getBindingResult().getFieldErrors().forEach(x -> errorMsg.append(x.getField()).append(x.getDefaultMessage()).append(","));
        String message = errorMsg.toString();
        log.warn("validation parameters error！The reason is:{}", message);
        return Result.error(Code.SYSTEM_ERROR, message);
    }

    @ExceptionHandler(Exception.class)
    public Result<?> runtimeExceptionHandler(RuntimeException e) {
        log.error("RuntimeException", e);
        return Result.error(Code.SYSTEM_ERROR, "系统错误");
    }

    // 处理 SaTokenException 异常
    @ExceptionHandler(SaTokenException.class)
    @ResponseBody
    public Result handleSaTokenException(SaTokenException e) {
        log.error("SaTokenException: {}", e.getMessage());
        return Result.error(Code.NOT_LOGIN);
    }

    // 处理 NotLoginException 异常
    @ExceptionHandler(NotLoginException.class)
    @ResponseBody
    public Result handleNotLoginException(NotLoginException e) {
        log.error("NotLoginException: {}", e.getMessage());
        return Result.error(Code.NOT_LOGIN);
    }


}
