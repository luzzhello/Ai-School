package com.cxk.template.domain.vo;

import lombok.Data;
import lombok.experimental.Accessors;
import com.cxk.template.common.model.PageParam;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

/**
 * 课程表展示类
 *
 * @author 校园小助手 2026/06/03
 */
@Data
@Accessors(chain = true)
public class CoursesVO extends PageParam {

/**
 * 课程ID
 */
    @JsonSerialize(using = ToStringSerializer.class)
private Long id;

/**
 * 课程名
 */
private String courseName;

/**
 * 学分
 */
    @JsonSerialize(using = ToStringSerializer.class)
private Long credits;

}
