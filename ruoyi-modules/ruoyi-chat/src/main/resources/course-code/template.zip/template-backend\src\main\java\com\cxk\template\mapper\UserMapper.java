package com.cxk.template.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cxk.template.domain.entity.UserEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户Mapper
 */
@Mapper
public interface UserMapper extends BaseMapper<UserEntity> {
}
