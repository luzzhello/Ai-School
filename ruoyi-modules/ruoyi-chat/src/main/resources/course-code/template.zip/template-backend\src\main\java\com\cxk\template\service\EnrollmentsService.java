package com.cxk.template.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import com.cxk.template.mapper.EnrollmentsMapper;
import com.cxk.template.domain.entity.EnrollmentsEntity;
import com.cxk.template.domain.vo.EnrollmentsVO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cn.hutool.core.collection.CollectionUtil;
import java.math.BigDecimal;

import jakarta.annotation.Resource;
import java.util.List;
import com.cxk.template.common.model.PageResult;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;


/**
 * 选课表Service实现类
 *
 * @author 校园小助手 2026/06/03
 */
@Slf4j
@Service
@Transactional(rollbackFor = Throwable.class)
public class EnrollmentsService extends ServiceImpl<EnrollmentsMapper, EnrollmentsEntity>{

    @Resource
    private EnrollmentsMapper enrollmentsMapper;

    /**
     * 新增选课表
     */
    public void saveEnrollments(EnrollmentsEntity enrollmentsEntity) {
        save(enrollmentsEntity);
    }

    /**
    * 删除选课表
    */
    public void removeEnrollmentss(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return;
        }
        removeByIds(ids);
    }

    /**
    * 修改选课表
    */
    public void updateEnrollments(EnrollmentsEntity enrollmentsEntity) {
        updateById(enrollmentsEntity);
    }


    /**
     * 根据ID查询选课表
     */
    public EnrollmentsEntity getEnrollmentsById(Long id) {
        return getById(id);
    }

    /**
     * 查看所有选课表
     */
    public List<EnrollmentsEntity> getAllEnrollmentss(EnrollmentsVO enrollmentsVO) {
        List<EnrollmentsEntity> enrollmentsEntityList =lambdaQuery().list();
        return enrollmentsEntityList;
    }

    /**
     * 分页查询选课表
     */
    public PageResult<EnrollmentsEntity> getEnrollmentsByPage(EnrollmentsVO enrollmentsVO) {
            Long studentId = enrollmentsVO.getStudentId();
            Long courseId = enrollmentsVO.getCourseId();
            Date enrollmentDate = enrollmentsVO.getEnrollmentDate();
            Page<EnrollmentsEntity> page = lambdaQuery()
                .eq(studentId != null, EnrollmentsEntity::getStudentId, studentId)
                .eq(courseId != null, EnrollmentsEntity::getCourseId, courseId)
                .eq(enrollmentDate != null, EnrollmentsEntity::getEnrollmentDate, enrollmentDate)
        .page(enrollmentsVO.toPage());

        PageResult<EnrollmentsEntity> pageResult = PageResult.convert2PageResult(page, page.getRecords());
        return pageResult;
    }
}
