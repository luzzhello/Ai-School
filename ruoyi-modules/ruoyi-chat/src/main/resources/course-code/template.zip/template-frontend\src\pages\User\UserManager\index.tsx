import {PlusOutlined} from '@ant-design/icons';
import type {ActionType, ProColumns} from '@ant-design/pro-components';
import {PageContainer, ProTable} from '@ant-design/pro-components';
import '@umijs/max';
import {Button, message, Modal, Space, Tag, Typography} from 'antd';
import React, {useRef, useState} from 'react';
import {saveUser, removeUsers, getUserByPage, updateUser} from "@/services/template-api/userController";
import {UploadImage} from "@/components";

/**
 * User管理页面
 *
 * @constructor
 */
const UserPage: React.FC = () => {
  // 是否显示新建窗口
  const [createModalVisible, setCreateModalVisible] = useState<boolean>(false);
  // 是否显示更新窗口
  const [updateModalVisible, setUpdateModalVisible] = useState<boolean>(false);
  //  表格操作
  const actionRef = useRef<ActionType>();
  // 当前User点击的数据
  const [currentRow, setCurrentRow] = useState<API.UserVO>();

  /**
   * 删除节点
   *
   * @param row
   */
  const handleDelete = async (row: API.UserVO) => {
    const hide = message.loading('正在删除');
    if (!row) return true;
    //确认删除
    Modal.confirm({
      title: '删除用户',
      content: '确定删除该用户吗？',
      okText: '确定',
      cancelText: '取消',
      onOk: async () => {
        await removeUsers({
          ids: [row.id],
        } as API.IdListForm);
        message.success('删除成功');
        actionRef?.current?.reload();
      },
    });
    hide();
  };

  /**
   * 添加节点
   * @param fields
   */
  const handleAdd = async (fields: API.UserEntity) => {
    const hide = message.loading('正在添加');
    try {
      await saveUser(fields);
      hide();
      message.success('创建成功');
      return true;
    } catch (error: any) {
      hide();
      message.error('创建失败，' + error.message);
      return false;
    }
  };

  /**
   * 更新节点
   *
   * @param fields
   */
  const handleUpdate = async (fields: API.UserEntity) => {
    const hide = message.loading('正在更新');
    try {
      await updateUser(fields);
      hide();
      message.success('更新成功');
      return true;
    } catch (error: any) {
      hide();
      message.error('更新失败，' + error.message);
      return false;
    }
  };
  /**
   * 表格列配置
   */
  const columns: ProColumns<API.UserVO>[] = [
    {
      title: 'id',
      dataIndex: 'id',
      valueType: 'text',
    },
    {
      title: '账号',
      dataIndex: 'userAccount',
      valueType: 'text',
    },
    {
      title: '密码',
      dataIndex: 'userPassword',
      valueType: 'text',
    },
    {
      title: '用户昵称',
      dataIndex: 'userName',
      valueType: 'text',
    },
    {
      title: '用户头像',
      dataIndex: 'userAvatar',
      valueType: 'image',
      hideInSearch: true,
      renderFormItem: (item, config, form) => {
        return <UploadImage
          onUpload={(url) => {
            form.setFieldsValue({userAvatar: url});
          }}
        />
      },
    },
    {
      title: '用户简介',
      dataIndex: 'userProfile',
      valueType: 'text',
    },
    {
      title: '手机号',
      dataIndex: 'userPhone',
      valueType: 'text',
    },
    {
      title: '用户角色',
      dataIndex: 'userRole',
      valueType: 'select',
      valueEnum: {
        'user': {text: '普通用户'},
        'admin': {text: '管理员'},
      },
      renderText: (text) => {
        //渲染 Tag
        return <>
          {text === 'admin' && <Tag color="purple">{text}</Tag>}
          {text === 'user' && <Tag color="green">{text}</Tag>}
        </>
      }
    },
    {
      title: '邀请码',
      dataIndex: 'inviteCode',
      valueType: 'text',
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      valueType: 'dateTime',
      hideInForm: true,
      hideInSearch: true,
      hideInTable: true,
    },
    {
      title: '更新时间',
      dataIndex: 'updateTime',
      valueType: 'dateTime',
      hideInForm: true,
      hideInSearch: true,
      hideInTable: true,
    },
    {
      title: '是否删除',
      dataIndex: 'deletedFlag',
      valueType: 'text',
      hideInForm: true,
      hideInSearch: true,
      hideInTable: true,
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <Space size="middle">
          <Typography.Link
            onClick={() => {
              setCurrentRow(record);
              setUpdateModalVisible(true);
            }}
          >
            修改
          </Typography.Link>
          <Typography.Link type="danger" onClick={() => handleDelete(record)}>
            删除
          </Typography.Link>
        </Space>
      ),
    },
  ];
  /**
   * 创建弹窗
   * @constructor
   */
  const CreateModal: React.FC = () => {
    return (
      <Modal
        destroyOnClose
        title={'创建'}
        open={createModalVisible}
        footer={null}
        onCancel={() => {
          setCreateModalVisible(false);
        }}
      >
        <ProTable
          type="form"
          columns={columns}
          onSubmit={async (values: API.UserEntity) => {
            const success = await handleAdd(values);
            if (success) {
              setCreateModalVisible(false);
              actionRef.current?.reload();
            }
          }}
        />
      </Modal>
    );
  };


  /**
   * 更新弹窗
   * @constructor
   */
  const UpdateModal: React.FC = () => {
    if (!currentRow) {
      return <></>;
    }

    return (
      <Modal
        destroyOnClose
        title={'更新'}
        open={updateModalVisible}
        footer={null}
        onCancel={() => {
          setUpdateModalVisible(false);
        }}
      >
        <ProTable
          type="form"
          columns={columns}
          form={{
            initialValues: currentRow,
          }}
          onSubmit={async (values: API.UserEntity) => {
            const success = await handleUpdate({
              ...values,
              id: currentRow?.id
            } as any);
            if (success) {
              setUpdateModalVisible(false);
              setCurrentRow(undefined);
              actionRef.current?.reload();
            }
          }}
        />
      </Modal>
    );
  };
  return (
    <PageContainer>
      <ProTable<API.UserVO>
        headerTitle={'用户管理'}
        actionRef={actionRef}
        rowKey="key"
        search={{
          labelWidth: 120,
        }}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              setCreateModalVisible(true);
            }}
          >
            <PlusOutlined/> 新建
          </Button>,
        ]}
        request={async (params, sort, filter) => {
          const sortField = Object.keys(sort)?.[0];
          const sortOrder = sort?.[sortField] ?? undefined;
          console.log(params, sort, filter)
          const {data, code} = await getUserByPage({
            pageSize: params.pageSize,
            pageNumber: params.current,
            ...params,
            sortField,
            sortOrder,
            ...filter,
          } as API.UserVO);
          return {
            success: code === 0,
            data: data.records || [],
            total: Number(data?.total) || 0,
          };
        }}
        pagination={{
          onChange: (page) => console.log(page),
          showSizeChanger: true,
        } as any}
        columns={columns}
      />
      <CreateModal/>
      <UpdateModal/>
    </PageContainer>
  );
};
export default UserPage;
