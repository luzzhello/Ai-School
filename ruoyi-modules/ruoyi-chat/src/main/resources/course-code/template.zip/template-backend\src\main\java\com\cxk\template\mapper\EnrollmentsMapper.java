package com.cxk.template.mapper;

import com.cxk.template.domain.entity.EnrollmentsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


/**
 * 选课表Mapper
 *
 * @author 校园小助手 2026/06/03
 */
@Mapper
public interface EnrollmentsMapper extends BaseMapper<EnrollmentsEntity> {

}
