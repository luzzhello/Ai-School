/**
 * 本地后端地址
 */
export const BACKEND_HOST_LOCAL = "http://localhost:10000";

/**
 * 线上后端地址
 */
export const BACKEND_HOST_PROD = "https://localhost:10000";

/**
 * 默认的顶级菜单id为0
 */
export const MENU_DEFAULT_PARENT_ID = 0;
