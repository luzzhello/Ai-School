package com.cxk.template.common.exception;


import com.cxk.template.common.model.Code;

/**
 * 自定义异常类
 */
public class BusinessException extends RuntimeException {

    /**
     * 错误码
     */
    private final int code;

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    public BusinessException(Code Code) {
        super(Code.getMessage());
        this.code = Code.getCode();
    }

    public BusinessException(String message) {
        super(message);
        this.code = Code.SYSTEM_ERROR.getCode();
    }



    public BusinessException(Code Code, String message) {
        super(message);
        this.code = Code.getCode();
    }

    public int getCode() {
        return code;
    }
}
