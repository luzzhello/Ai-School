package com.cxk.template.controller;

import com.cxk.template.domain.entity.EnrollmentsEntity;
import com.cxk.template.service.EnrollmentsService;
import com.cxk.template.domain.vo.EnrollmentsVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
import com.cxk.template.common.model.Result;
import com.cxk.template.common.model.PageResult;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import com.cxk.template.common.model.IdListForm;

/**
 * 选课表Controller层
 *
 * @author 校园小助手 2026/06/03
 */
@Slf4j
@RestController
@RequestMapping("/enrollments")
public class EnrollmentsController {

    @Resource
    private EnrollmentsService enrollmentsService;


    /**
     * 新增选课表
     */
    @PostMapping("/save")
    @Operation(summary = "保存选课表数据}")
    public Result<Void> saveEnrollments( @RequestBody EnrollmentsEntity enrollmentsEntity) {
        enrollmentsService.saveEnrollments(enrollmentsEntity);
        return Result.success();
    }

    /**
     * 删除选课表
     */
    @PostMapping("/remove")
    @Operation(summary = "删除选课表数据}")
    public Result<Void> removeEnrollmentss( @RequestBody IdListForm idListForm) {
        List<Long> ids = idListForm.getIds();
        enrollmentsService.removeEnrollmentss(ids);
        return Result.success();
    }

    /**
     * 修改选课表
     */
    @PostMapping("/update")
    @Operation(summary = "修改选课表数据}")
    public Result<Void> updateEnrollments(@RequestBody EnrollmentsEntity enrollmentsEntity) {
        enrollmentsService.updateEnrollments(enrollmentsEntity);
        return Result.success();
    }

    /**
      * 根据ID查询选课表
      */
    @GetMapping("/get")
    @Operation(summary = "根据ID查询选课表数据}")
    public Result<EnrollmentsEntity> getEnrollmentsById(@RequestParam Long id) {
        EnrollmentsEntity enrollmentsEntity = enrollmentsService.getEnrollmentsById(id);
        return Result.success(enrollmentsEntity);
    }

    /**
     * 查看所有选课表
     */
    @PostMapping("/getAll")
    @Operation(summary = "查看所有选课表数据}")
    public Result<List<EnrollmentsEntity>> getAllEnrollmentss(@RequestBody EnrollmentsVO enrollmentsVO) {
        List<EnrollmentsEntity> enrollmentsEntityList = enrollmentsService.getAllEnrollmentss(enrollmentsVO);
        return Result.success(enrollmentsEntityList);
    }

    /**
     * 分页查询选课表
     */
    @PostMapping("/getPage")
    @Operation(summary = "分页查询选课表数据}")
    public Result<PageResult<EnrollmentsEntity>> getEnrollmentsByPage( @RequestBody EnrollmentsVO enrollmentsVO) {
        PageResult<EnrollmentsEntity> pageResult = enrollmentsService.getEnrollmentsByPage(enrollmentsVO);
        return Result.success(pageResult);
    }
}
