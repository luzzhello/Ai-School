import {PageContainer} from '@ant-design/pro-components';
import {history, useModel} from '@umijs/max';
import {Alert, Button, Card, ConfigProvider, Image, Space, theme, Typography} from 'antd';
import React, {useContext, useState} from 'react';
import {FileTwoTone, PlayCircleFilled} from "@ant-design/icons";
import {css} from '@emotion/css';

const StartButton: React.FC = () => {
  const {getPrefixCls} = useContext(ConfigProvider.ConfigContext);
  const rootPrefixCls = getPrefixCls();
  const linearGradientButton = css`
    &.${rootPrefixCls}-btn-primary:not([disabled]):not(.${rootPrefixCls}-btn-dangerous) {
      border-width: 0;
      > span {
        position: relative;
      }
      &::before {
        content: '';
        background: linear-gradient(135deg, #6253E1, #04BEFE);
        position: absolute;
        inset: 0;
        opacity: 1;
        transition: all 0.3s;
        border-radius: inherit;
      }

      &:hover::before {
        opacity: 0;
      }
    }
  `;
  return (
    <ConfigProvider
      button={{
        className: linearGradientButton,
      }}
    >
      <Space>
        <Button type="primary" size="large" icon={<PlayCircleFilled/>}
                onClick={() => {
                  history.push("/")
                }}
        >
          开始使用
        </Button>
      </Space>
    </ConfigProvider>
  );
};


/**
 * 每个单独的卡片，为了复用样式抽成了组件
 * @param param0
 * @returns
 */
const InfoCard: React.FC<{
  title: string;
  index: number;
  desc: string;
  image?: string;
}> = ({title, image, index, desc}) => {
  const {useToken} = theme;

  const {token} = useToken();
  const [visible, setVisible] = useState(false);
  return (
    <div
      style={{
        backgroundColor: token.colorBgContainer,
        boxShadow: token.boxShadow,
        borderRadius: '8px',
        fontSize: '14px',
        color: token.colorTextSecondary,
        lineHeight: '22px',
        padding: '16px 19px',
        minWidth: '220px',
        flex: 1,
      }}
    >
      <div
        style={{
          display: 'flex',
          gap: '4px',
          alignItems: 'center',
        }}
      >
        <div
          style={{
            width: 48,
            height: 48,
            lineHeight: '22px',
            backgroundSize: '100%',
            textAlign: 'center',
            padding: '8px 16px 16px 12px',
            color: '#FFF',
            fontWeight: 'bold',
            backgroundImage:
              "url('https://gw.alipayobjects.com/zos/bmw-prod/daaf8d50-8e6d-4251-905d-676a24ddfa12.svg')",
          }}
        >
          {index}
        </div>
        <div
          style={{
            fontSize: '16px',
            color: token.colorText,
            paddingBottom: 8,
          }}
        >
          {title}
        </div>
      </div>
      <div
        style={{
          fontSize: '14px',
          color: token.colorTextSecondary,
          textAlign: 'justify',
          lineHeight: '22px',
          marginBottom: 8,
        }}
      >
        {desc}
      </div>
      {image && (
        <>
          <a rel="noreferrer" onClick={() => {
            setVisible(true)
          }}>
            了解更多 {'>'}
          </a>
          <Image
            width={200}
            style={{display: 'none'}}
            preview={{
              visible,
              src: image,
              onVisibleChange: (value) => {
                setVisible(value);
              },
            }}
          />
        </>


      )}
    </div>
  );
};

const Index: React.FC = () => {
  const {token} = theme.useToken();
  const {initialState} = useModel('@@initialState');
  return (
    <PageContainer>
      <Card
        style={{
          borderRadius: 8,
        }}
        bodyStyle={{
          backgroundImage:
            initialState?.settings?.navTheme === 'realDark'
              ? 'background-image: linear-gradient(75deg, #1A1B1F 0%, #191C1F 100%)'
              : 'background-image: linear-gradient(75deg, #FBFDFF 0%, #F5F7FF 100%)',
        }}
      >
        <div
          style={{
            backgroundPosition: '100% -30%',
            backgroundRepeat: 'no-repeat',
            backgroundSize: '274px auto',
            backgroundImage:
              "url('https://gw.alipayobjects.com/mdn/rms_a9745b/afts/img/A*BuFmQqsB2iAAAAAAAAAAAAAAARQnAQ')",
          }}
        >
          <div
            style={{
              fontSize: '20px',
              color: token.colorTextHeading,
            }}
          >
            模版项目生成
          </div>
          <p
            style={{
              fontSize: '14px',
              color: token.colorTextSecondary,
              lineHeight: '22px',
              marginTop: 16,
              marginBottom: 32,
              width: '65%',
            }}
          >
            本平台是为了作为前后端开发的模版。<br/>
          </p>
          <Card>
            <Alert
              message={'一键生成前后端管理模版！'}
              type="success"
              showIcon
              banner
              style={{
                margin: -12,
                marginBottom: 24,
              }}
            />
            <Typography.Title
              level={2}
              style={{
                textAlign: 'center',
              }}
            >
              <FileTwoTone/> 模版项目生成
            </Typography.Title>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: 16,
              }}
            >
              <InfoCard
                index={1}
                title="后端代码生成"
                desc="帮助你快速生成后端代码，简化开发过程。通过自动化工具，减少了重复劳动，提升开发效率，允许开发者专注于业务逻辑的实现"
                image={'/welcome/collect/example1.png'}
              />
              <InfoCard
                index={2}
                title="前端页面生成"
                desc="前端页面生成器使得用户可以通过简单的配置，快速创建标准化的前端页面"
                image={'/welcome/collect/example2.png'}
              />
              <InfoCard
                index={3}
                title="OpenAPI接口生成"
                desc="使用 OpenAPI 接口生成工具，开发者可以快速定义并生成符合规范的 API 接口文档"
                image={'/welcome/collect/example3.png'}
              />
            </div>
            <div style={{
              marginTop: 20,
              textAlign: 'center',
            }}>
              <Space>
                <StartButton/>
              </Space>
            </div>

          </Card>
        </div>
      </Card>
    </PageContainer>
  );
};

export default Index;
