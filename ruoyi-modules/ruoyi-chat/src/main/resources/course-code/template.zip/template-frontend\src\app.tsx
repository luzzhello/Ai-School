import {AvatarDropdown, AvatarName, Footer} from '@/components';
import {LinkOutlined} from '@ant-design/icons';
import type {Settings as LayoutSettings} from '@ant-design/pro-components';
import {SettingDrawer} from '@ant-design/pro-components';
import {Access, history, Link, useAccess} from '@umijs/max';
import defaultSettings from '../config/defaultSettings';
import {requestConfig} from './requestConfig';
import {getCurrentUser} from "@/services/template-api/userController";
import React from "react";
import NoAccessPage from "@/pages/Public/403";
import {CURRENT_USER} from "@/constants/globalStorage";

const isDev = process.env.NODE_ENV === 'development';

const loginPath = '/user/login';
const WHITE_LIST = ['/', '/welcome', '/user/login', "/college/submit", "/account/changePassword"]

/**
 * @see  https://umijs.org/zh-CN/plugins/plugin-initial-state
 * */
export async function getInitialState(): Promise<{
  settings?: Partial<LayoutSettings>;
  currentUser?: API.UserVO;
  loading?: boolean;
  fetchUserInfo?: () => Promise<API.UserVO | undefined>;
  getRoutes?: () => Promise<{ menuData: any; allMenuData: string[] }>;
  token?: string;
  menuData?: any;
  allMenuData?: string[];
}> {
  const fetchUserInfo = async () => {
    try {
      const res: API.ResultUserVO = await getCurrentUser();
      localStorage.setItem(CURRENT_USER, JSON.stringify(res.data));
      return res.data
    } catch (error) {
      history.push(loginPath);
    }
    return undefined;
  };
  const {location} = history;

  for (const path of WHITE_LIST) {
    if (path === location.pathname || (location.pathname.startsWith(path) && path !== "/")) {
      // 获取用户信息
      const storedUser = localStorage.getItem(CURRENT_USER);
      const currentUser = storedUser ? JSON.parse(storedUser) : undefined;
      return {
        fetchUserInfo,
        currentUser: currentUser && Object.keys(currentUser).length > 0 ? currentUser : undefined,
        settings: defaultSettings as Partial<LayoutSettings>,
      } as any;
    }
  }

  const currentUser = await fetchUserInfo();
  return {
    fetchUserInfo,
    currentUser,
    settings: defaultSettings as Partial<LayoutSettings>,
  } as any;
}

// ProLayout 支持的api https://procomponents.ant.design/components/layout
export const layout = ({initialState, setInitialState}) => {
  const access = useAccess()
  return {
    avatarProps: {
      src: initialState?.currentUser?.userAvatar,
      title: <AvatarName/>,
      render: (_, avatarChildren) => {
        return <Access accessible={access.isLogin}>
          <AvatarDropdown>{avatarChildren}</AvatarDropdown>
        </Access>;
      },
    },
    waterMarkProps: {
      content: initialState?.currentUser?.userName,
    },
    footerRender: () => <Footer/>,
    onPageChange: () => {
    },
    bgLayoutImgList: [
      {
        src: 'https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/D2LWSqNny4sAAAAAAAAAAAAAFl94AQBr',
        left: 85,
        bottom: 100,
        height: '303px',
      },
      {
        src: 'https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/C2TWRpJpiC0AAAAAAAAAAAAAFl94AQBr',
        bottom: -68,
        right: -45,
        height: '303px',
      },
      {
        src: 'https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/F6vSTbj8KpYAAAAAAAAAAAAAFl94AQBr',
        bottom: 0,
        left: 0,
        width: '331px',
      },
    ],
    menuHeaderRender: undefined,
    // 自定义 403 页面
    unAccessible: <NoAccessPage/>,
    // 增加一个 loading 的状态
    childrenRender: (children) => {
      // if (initialState?.loading) return <PageLoading />;
      return (
        <>
          {children}
          {
            isDev && (
              <SettingDrawer
                disableUrlParams
                enableDarkTheme
                settings={initialState?.settings}
                onSettingChange={(settings) => {
                  setInitialState((preInitialState) => ({
                    ...preInitialState,
                    settings,
                  }));
                }}
              />
            )
          }
        </>
      );
    },
    ...initialState?.settings,
  };
};

/**
 * @name request 配置，可以配置错误处理
 * 它基于 axios 和 ahooks 的 useRequest 提供了一套统一的网络请求和错误处理方案。
 * @doc https://umijs.org/docs/max/request#配置
 */
export const request = {
  ...requestConfig,
};
