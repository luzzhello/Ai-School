// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** 获取当前用户信息  GET /user/current */
export async function getCurrentUser(options?: { [key: string]: any }) {
  return request<API.ResultUserEntity>('/user/current', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 根据ID查询用户数据  GET /user/get */
export async function getUserById(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getUserByIdParams,
  options?: { [key: string]: any },
) {
  return request<API.ResultUserEntity>('/user/get', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 分页查询用户数据  POST /user/getPage */
export async function getUserByPage(body: API.UserVO, options?: { [key: string]: any }) {
  return request<API.ResultPageResultUserEntity>('/user/getPage', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 退出登录 GET /user/logout */
export async function logout(options?: { [key: string]: any }) {
  return request<API.ResultBoolean>('/user/logout', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 登录 POST /user/public/login */
export async function login(body: API.UserVO, options?: { [key: string]: any }) {
  return request<API.ResultUserVO>('/user/public/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 注册 POST /user/public/register */
export async function register(body: API.UserVO, options?: { [key: string]: any }) {
  return request<API.ResultBoolean>('/user/public/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /user/remove */
export async function removeUsers(body: API.IdListForm, options?: { [key: string]: any }) {
  return request<API.Result>('/user/remove', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 保存用户数据 POST /user/save */
export async function saveUser(body: API.UserEntity, options?: { [key: string]: any }) {
  return request<API.ResultLong>('/user/save', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 更新用户数据  POST /user/update */
export async function updateUser(body: API.UserEntity, options?: { [key: string]: any }) {
  return request<API.Result>('/user/update', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
