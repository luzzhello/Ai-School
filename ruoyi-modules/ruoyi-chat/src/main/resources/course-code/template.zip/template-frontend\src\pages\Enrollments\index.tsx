import {PlusOutlined} from '@ant-design/icons';
import type {ActionType, ProColumns} from '@ant-design/pro-components';
import {PageContainer, ProTable} from '@ant-design/pro-components';
import '@umijs/max';
import {Button, message, Modal, Space, Typography} from 'antd';
import React, {useRef, useState, useEffect} from 'react';
import {UploadImage} from "@/components/UploadImage";
import {saveEnrollments, removeEnrollmentss, getEnrollmentsByPage, updateEnrollments} from "@/services/template-api/enrollmentsController";
import {getAllStudentss} from "@/services/template-api/StudentsController";
import {getAllCoursess} from "@/services/template-api/CoursesController";

/**
 * EnrollmentsEntity管理页面
 *
 * @constructor
 */
const EnrollmentsEntityPage: React.FC = () => {
    // 是否显示新建窗口
    const [modalVisible, setModalVisible] = useState<boolean>(false);
    // 是否显示修改窗口
    const [UpdateModalVisible, setUpdateModalVisible] = useState<boolean>(false);
    //  表格操作
    const actionRef = useRef<ActionType>();
    // 当前EnrollmentsEntity点击的数据
    const [currentRow, setCurrentRow] = useState<API.EnrollmentsEntity | undefined>();

        // 外键关系状态管理
            const [studentIdList, setStudentIdList] = useState<API.StudentsVO[]>([]);
            const [studentIdLoading, setStudentIdLoading] = useState<boolean>(true);
            const [studentIdOptions, setStudentIdOptions] = useState([]);
            const [courseIdList, setCourseIdList] = useState<API.CoursesVO[]>([]);
            const [courseIdLoading, setCourseIdLoading] = useState<boolean>(true);
            const [courseIdOptions, setCourseIdOptions] = useState([]);

        /**
         * 初始化外键数据
         */
            useEffect(() => {
                const fetchConets = async () => {
                    try {
                        const res = await getAllStudentss({
                            pageSize: 10,
                            pageNumber: 1,
                        } as API.StudentsVO);
                        if (res.code === 0) {
                            setStudentIdList(res.data || []);
                        } else {
                            message.error('获取关联学生列表失败：' + res.message);
                        }

                    } catch (error) {
                        message.error('获取院系ID列表失败');
                    } finally {
                        setStudentIdLoading(false);
                    }
                };
                fetchConets();
            }, []);
            useEffect(() => {
                const fetchConets = async () => {
                    try {
                        const res = await getAllCoursess({
                            pageSize: 10,
                            pageNumber: 1,
                        } as API.CoursesVO);
                        if (res.code === 0) {
                            setCourseIdList(res.data || []);
                        } else {
                            message.error('获取关联课程列表失败：' + res.message);
                        }

                    } catch (error) {
                        message.error('获取院系ID列表失败');
                    } finally {
                        setCourseIdLoading(false);
                    }
                };
                fetchConets();
            }, []);
        /**
         * 更新外键选项
         */
            useEffect(() => {
                if (studentIdList && studentIdList.length > 0) {
                    const newOptions = studentIdList.map(item => ({
                        value: item.id,
                        label: item.name,
                    }));
                    setStudentIdOptions(newOptions);
                }
            }, [studentIdList]);
            useEffect(() => {
                if (courseIdList && courseIdList.length > 0) {
                    const newOptions = courseIdList.map(item => ({
                        value: item.id,
                        label: item.courseName,
                    }));
                    setCourseIdOptions(newOptions);
                }
            }, [courseIdList]);

    /**
     * 删除节点
     *
     * @param row
     */
    const handleDelete = async (row: API.EnrollmentsEntity) => {
        const hide = message.loading('正在删除');
        if (!row) return ;
        try {
            Modal.confirm({
                title: '删除选课表',
                content: '确定删除该选课表吗？',
                okText: '确认',
                cancelText: '取消',
                onOk: async () => {
                    await removeEnrollmentss({
                        ids: [row.courseId],
                    } as API.IdListForm);
                    message.success('删除成功');
                    actionRef?.current?.reload();
                },
            })

        } catch (error: any) {
            message.error('删除失败请重试！');
        }
        hide();
    };

    /**
     * 添加节点
     * @param fields
     */
    const handleSubmit = async (fields: API.EnrollmentsEntity) => {
        const hide = message.loading(currentRow ? '正在更新' : '正在添加');
        try {
            if (currentRow?.courseId) {
                await updateEnrollments({
                    ...fields,
                        courseId: currentRow.courseId,
                });
            } else {
                await saveEnrollments(fields);
            }
            hide();
            message.success(currentRow ? '更新成功' : '添加成功');
            setModalVisible(false);
            setCurrentRow(undefined);
            actionRef.current?.reload();
        } catch (error: any) {
            message.error((currentRow ? '更新' : '创建') + '失败：' + error.message);
        }
        hide();
    };

    /**
     * 表格列配置
     */
    const columns: ProColumns<API.EnrollmentsEntity>[] = [
            {
                title: '关联学生',
                dataIndex: 'studentId',
                    valueType: 'select',
                    renderText: (_, record) => {
                                const item = studentIdList.find(item => item.id === record.studentId);
                                return item?.name || '-';
                    },
                    fieldProps: {
                                loading: studentIdLoading,
                                options: studentIdOptions,
                        placeholder: '请选择关联学生',
                        allowClear: true,
                        showSearch: true,
                        filterOption: (input, option) =>
                            (option?.label ?? '').toLowerCase().includes(input.toLowerCase()),
                    }
                    hideInForm: true,
                    hideInSearch: true,
            },
            {
                title: '关联课程',
                dataIndex: 'courseId',
                    valueType: 'select',
                    renderText: (_, record) => {
                                const item = courseIdList.find(item => item.id === record.courseId);
                                return item?.courseName || '-';
                    },
                    fieldProps: {
                                loading: courseIdLoading,
                                options: courseIdOptions,
                        placeholder: '请选择关联课程',
                        allowClear: true,
                        showSearch: true,
                        filterOption: (input, option) =>
                            (option?.label ?? '').toLowerCase().includes(input.toLowerCase()),
                    }
                    hideInForm: true,
                    hideInSearch: true,
            },
            {
                title: '注册日期',
                dataIndex: 'enrollmentDate',
                    valueType: 'dateTime',
            },
        {
            title: '操作',
            dataIndex: 'option',
            valueType: 'option',
            render: (_, record) => (
                <Space size="middle">
                    <Typography.Link
                        onClick={() => {
                            setCurrentRow(record);
                            setUpdateModalVisible(true);
                        }}
                    >
                        修改
                    </Typography.Link>
                    <Typography.Link type="danger" onClick={() => handleDelete(record)}>
                        删除
                    </Typography.Link>
                </Space>
            ),
        },
    ];

    /**
     * 创建弹窗
     * @constructor
     */
    const CreateOrUpdateModal: React.FC = () => {
        return (
            <Modal
                destroyOnClose
                title={currentRow ? '修改' : '新建'}
                open={modalVisible}
                footer={null}
                onCancel={() => {
                    setModalVisible(false);
                    setCurrentRow(undefined);
                }}
            >
                <ProTable
                    type="form"
                    columns={columns}
                    form={{
                        initialValues: currentRow,
                    }}
                    onSubmit={handleSubmit}
                />
            </Modal>
        );
    };

    /**
     * 修改弹窗
     * @constructor
     */
    const UpdateModal: React.FC = () => {
        return (
            <Modal
                destroyOnClose
                title="修改选课表"
                open={UpdateModalVisible}
                footer={null}
                onCancel={() => {
                    setUpdateModalVisible(false);
                    setCurrentRow(undefined);
                }}
            >
                <ProTable
                    type="form"
                    columns={columns}
                    form={{
                        initialValues: currentRow,
                    }}
                    onSubmit={async (fields) => {
                        const hide = message.loading('正在更新');
                        try {
                            await updateEnrollments({
                                ...fields,
                                    courseId: currentRow?.courseId,
                            });
                            hide();
                            message.success('更新成功');
                            setUpdateModalVisible(false);
                            setCurrentRow(undefined);
                            actionRef.current?.reload();
                        } catch (error: any) {
                            hide();
                            message.error('更新失败：' + error.message);
                        }
                    }}
                />
            </Modal>
        );
    };

    return (
        <PageContainer>
            <ProTable<API.EnrollmentsEntity>
                headerTitle={'选课表管理'}
                actionRef={actionRef}
                rowKey="key"
                search={{
                    labelWidth: 120,
                }}
                toolBarRender={() => [
                    <Button
                        type="primary"
                        key="primary"
                        onClick={() => {
                            setCurrentRow(undefined);
                            setModalVisible(true);
                        }}
                    >
                        <PlusOutlined/> 新建
                    </Button>,
                ]}
                request={async (params, sort, filter) => {
                    const sortField = Object.keys(sort)?.[0];
                    const sortOrder = sort?.[sortField] ?? undefined;
                    const {data, code} = await getEnrollmentsByPage({
                        pageSize: params.pageSize,
                        pageNumber: params.current,
                        ...params,
                        sortField,
                        sortOrder,
                        ...filter,
                    } as API.EnrollmentsVO);
                    return {
                        success: code === 0,
                        data: data.records || [],
                        total: Number(data?.total) || 0,
                    };
                }}
                pagination={{
                    showSizeChanger: true,
                } as any}
                columns={columns}
            />
            <CreateOrUpdateModal/>
            <UpdateModal/>
        </PageContainer>
    );
};
export default EnrollmentsEntityPage;
