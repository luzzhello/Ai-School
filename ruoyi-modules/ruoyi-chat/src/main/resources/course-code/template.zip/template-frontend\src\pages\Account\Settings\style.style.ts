import {createStyles} from 'antd-style';

const useStyles = createStyles(({token}) => {
  return {
    main: {
      width: '100%',
      padding: '24px 0',
      backgroundColor: 'transparent',
    },
    right: {
      width: '100%',
      transition: 'all 0.3s',
    },
  } as any;
});

export default useStyles;
