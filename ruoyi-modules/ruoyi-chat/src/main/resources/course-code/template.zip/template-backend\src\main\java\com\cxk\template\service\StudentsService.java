package com.cxk.template.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import com.cxk.template.mapper.StudentsMapper;
import com.cxk.template.domain.entity.StudentsEntity;
import com.cxk.template.domain.vo.StudentsVO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cn.hutool.core.collection.CollectionUtil;
import java.math.BigDecimal;

import jakarta.annotation.Resource;
import java.util.List;
import com.cxk.template.common.model.PageResult;
import org.apache.commons.lang3.StringUtils;



/**
 * 学生表Service实现类
 *
 * @author 校园小助手 2026/06/03
 */
@Slf4j
@Service
@Transactional(rollbackFor = Throwable.class)
public class StudentsService extends ServiceImpl<StudentsMapper, StudentsEntity>{

    @Resource
    private StudentsMapper studentsMapper;

    /**
     * 新增学生表
     */
    public void saveStudents(StudentsEntity studentsEntity) {
        save(studentsEntity);
    }

    /**
    * 删除学生表
    */
    public void removeStudentss(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return;
        }
        removeByIds(ids);
    }

    /**
    * 修改学生表
    */
    public void updateStudents(StudentsEntity studentsEntity) {
        updateById(studentsEntity);
    }


    /**
     * 根据ID查询学生表
     */
    public StudentsEntity getStudentsById(Long id) {
        return getById(id);
    }

    /**
     * 查看所有学生表
     */
    public List<StudentsEntity> getAllStudentss(StudentsVO studentsVO) {
        List<StudentsEntity> studentsEntityList =lambdaQuery().list();
        return studentsEntityList;
    }

    /**
     * 分页查询学生表
     */
    public PageResult<StudentsEntity> getStudentsByPage(StudentsVO studentsVO) {
            Long id = studentsVO.getId();
            String name = studentsVO.getName();
            Long age = studentsVO.getAge();
            String email = studentsVO.getEmail();
            Page<StudentsEntity> page = lambdaQuery()
                .eq(id != null, StudentsEntity::getId, id)
                .eq(name != null, StudentsEntity::getName, name)
                .eq(age != null, StudentsEntity::getAge, age)
                .eq(email != null, StudentsEntity::getEmail, email)
        .page(studentsVO.toPage());

        PageResult<StudentsEntity> pageResult = PageResult.convert2PageResult(page, page.getRecords());
        return pageResult;
    }
}
