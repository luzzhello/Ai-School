package com.cxk.template.domain.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.cxk.template.common.model.PageParam;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 用户展示类
 */
@Data
public class UserVO extends PageParam implements Serializable {
    @Schema(description = "id")
    private Long id;
    @Schema(description = "账号")
    private String userAccount;
    @Schema(description = "密码")
    @TableField("userPassword")
    private String userPassword;
    @Schema(description = "用户昵称")
    private String userName;
    @Schema(description = "用户头像")
    private String userAvatar;
    @Schema(description = "用户简介")
    private String userProfile;
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createTime;
    @Schema(description = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime updateTime;
    @Schema(description = "用户角色")
    private String userRole;
    @Schema(description = "token")
    private String token;
}
