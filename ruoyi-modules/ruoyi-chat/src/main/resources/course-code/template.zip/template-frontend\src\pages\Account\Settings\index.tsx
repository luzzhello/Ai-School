import { PageContainer } from '@ant-design/pro-components';
import { Card } from 'antd';
import React from 'react';
import BaseView from './components/base';
import useStyles from './style.style';
import { UserNameDisplay } from '@/components';

const Settings: React.FC = () => {
  const {styles} = useStyles();

  return (
    <PageContainer title="个人信息设置">
      <div className={styles.main}>
        <div className={styles.right} style={{ width: '100%', maxWidth: '1000px', margin: '0 auto' }}>
          <Card bordered={false} style={{ marginBottom: 24 }}>
            <BaseView />
          </Card>
        </div>
      </div>
      <UserNameDisplay size="large" />
    </PageContainer>
  );
};

export default Settings;
