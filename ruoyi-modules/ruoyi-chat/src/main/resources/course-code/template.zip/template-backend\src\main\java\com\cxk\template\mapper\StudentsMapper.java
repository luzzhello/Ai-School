package com.cxk.template.mapper;

import com.cxk.template.domain.entity.StudentsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


/**
 * 学生表Mapper
 *
 * @author 校园小助手 2026/06/03
 */
@Mapper
public interface StudentsMapper extends BaseMapper<StudentsEntity> {

}
