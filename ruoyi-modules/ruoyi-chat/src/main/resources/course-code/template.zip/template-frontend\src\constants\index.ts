import {MENU_TYPE_ENUM, USER_ROLE_ENUM} from "@/constants/common-enums";
import {BACKEND_HOST_LOCAL, BACKEND_HOST_PROD} from "@/constants/common-constant";
import {PASSWORD_REGEX} from "@/constants/regex";
import {CURRENT_USER} from "@/constants/globalStorage";


export default {
  BACKEND_HOST_LOCAL,
  BACKEND_HOST_PROD,
  MENU_TYPE_ENUM,
  USER_ROLE_ENUM,
  PASSWORD_REGEX,
  CURRENT_USER
}
