package com.cxk.template.domain.vo;

import lombok.Data;
import lombok.experimental.Accessors;
import com.cxk.template.common.model.PageParam;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

/**
 * 选课表展示类
 *
 * @author 校园小助手 2026/06/03
 */
@Data
@Accessors(chain = true)
public class EnrollmentsVO extends PageParam {

/**
 * 关联学生
 */
    @JsonSerialize(using = ToStringSerializer.class)
private Long studentId;

/**
 * 关联课程
 */
    @JsonSerialize(using = ToStringSerializer.class)
private Long courseId;

/**
 * 注册日期
 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
private Date enrollmentDate;

}
