package com.cxk.template.common.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 通用返回类
 */
@Data
public class Result<T> implements Serializable {

    private int code;

    private T data;

    private String message;

    public Result(int code, T data, String message) {
        this.code = code;
        this.data = data;
        this.message = message;
    }

    public Result(int code, T data) {
        this(code, data, "");
    }

    public Result(Code errorCode) {
        this(errorCode.getCode(), null, errorCode.getMessage());
    }


    /**
     * 成功
     *
     * @param data
     * @param <T>
     * @return
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(0, data, "ok");
    }

    /**
     * 成功
     */
    public static <T> Result<T> success() {
        return new Result<>(0, null, "ok");
    }

    /**
     * 失败
     *
     * @param Code
     * @return
     */
    public static Result error(Code Code) {
        return new Result<>(Code);
    }

    /**
     * 失败
     *
     * @param message
     * @return
     */
    public static Result error(String message) {
        return new Result<>(Code.SYSTEM_ERROR.getCode(), message);
    }

    /**
     * 失败
     *
     * @param code
     * @param message
     * @return
     */
    public static Result error(int code, String message) {
        return new Result(code, null, message);
    }

    /**
     * 失败
     *
     * @param Code
     * @return
     */
    public static Result error(Code Code, String message) {
        return new Result(Code.getCode(), null, message);
    }
}
