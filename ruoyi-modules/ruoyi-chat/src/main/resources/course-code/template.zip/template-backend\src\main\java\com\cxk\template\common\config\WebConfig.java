package com.cxk.template.common.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.File;
import java.nio.file.Paths;

/**
 * 跨域问题解决：允许所有请求 携带token的时候，获取不到token
 */
@Configuration
@Slf4j
public class WebConfig implements WebMvcConfigurer {
    @Autowired
    private FileStorageConfig fileStorageConfig;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                // 是否发送Cookie
                .allowCredentials(true)
                // 放行哪些原始域
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 添加本地文件访问映射
        String uploadDir = fileStorageConfig.getUploadDir();
        String baseUrl = fileStorageConfig.getBaseUrl();

        // 确保baseUrl以/开头且不以/结尾
        if (!baseUrl.startsWith("/")) {
            baseUrl = "/" + baseUrl;
        }
        if (baseUrl.endsWith("/")) {
            baseUrl = baseUrl.substring(0, baseUrl.length() - 1);
        }

        // 配置文件访问路径
        String urlPattern = baseUrl + "/**";

        // 获取上传目录的绝对路径
        String absolutePath = Paths.get(uploadDir).toAbsolutePath().toString();
        // 确保路径以/结尾，避免Windows和Linux路径分隔符的差异
        if (!absolutePath.endsWith(File.separator)) {
            absolutePath += File.separator;
        }

        String resourceLocation = "file:" + absolutePath;

        log.info("配置静态资源映射: URL模式 '{}' -> 资源位置 '{}'", urlPattern, resourceLocation);

        // 添加到资源处理器，确保静态资源可以被访问
        registry.addResourceHandler(urlPattern)
                .addResourceLocations(resourceLocation)
                .setCachePeriod(0) // 开发阶段禁用缓存，方便调试
                .resourceChain(true); // 启用资源链，提升性能

        // 添加Swagger相关资源处理
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
}
