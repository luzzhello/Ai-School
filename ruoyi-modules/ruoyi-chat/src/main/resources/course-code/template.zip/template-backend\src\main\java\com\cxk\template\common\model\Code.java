package com.cxk.template.common.model;


import lombok.AllArgsConstructor;
import lombok.Getter;


@AllArgsConstructor
@Getter
public enum Code {
    SUCCESS(0, "成功"),
    NOT_LOGIN(11002, "用户未登录"),
    SYSTEM_ERROR(10007, "系统错误");
    private int code;
    private String message;
}

