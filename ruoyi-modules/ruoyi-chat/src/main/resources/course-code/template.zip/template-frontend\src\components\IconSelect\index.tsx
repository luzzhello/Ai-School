import React, {useMemo, useState} from 'react';
import * as AntIcons from '@ant-design/icons';
import {SearchOutlined} from '@ant-design/icons';
import {Button, Input, Popover, Radio} from 'antd';
import './index.css'

const IconSelect = ({onIconSelect}) => {
  const outlinedIconArray = Object.keys(AntIcons).filter((e) =>
    e.toLowerCase().endsWith('outlined')
  );
  const filledIconArray = Object.keys(AntIcons).filter((e) =>
    e.toLowerCase().endsWith('filled')
  );
  const twoToneIconArray = Object.keys(AntIcons).filter((e) =>
    e.toLowerCase().endsWith('twotone')
  );

  const [visible, setVisible] = useState(false);
  const [iconStyle, setIconStyle] = useState('outlined');
  const [searchValue, setSearchValue] = useState('');
  const [showMoreIndex, setShowMoreIndex] = useState(35);

  const selectIconArray = useMemo(() => {
    let tempArray;
    if (iconStyle === 'outlined') {
      tempArray = outlinedIconArray;
    } else if (iconStyle === 'filled') {
      tempArray = filledIconArray;
    } else {
      tempArray = twoToneIconArray;
    }

    if (searchValue) {
      return tempArray.filter((e) =>
        e.toLowerCase().includes(searchValue.toLowerCase())
      );
    }

    return tempArray;
  }, [iconStyle, searchValue, outlinedIconArray, filledIconArray, twoToneIconArray]);

  const iconLoopArray = useMemo(
    () => selectIconArray.slice(0, showMoreIndex),
    [selectIconArray, showMoreIndex]
  );

  const handleClick = (icon) => {
    setVisible(false);
    if (onIconSelect) {
      onIconSelect(icon);
    }
  };

  return (
    <Popover
      content={
        <div className="icon-box">
          {iconLoopArray.map((item) => (
            <div
              key={item}
              className="icon-content"
              onClick={() => handleClick(item)}
            >
              {React.createElement(AntIcons[item])}
            </div>
          ))}
          {showMoreIndex > 0 && (
            <Button type="link" onClick={() => setShowMoreIndex(-1)}>
              点击展开更多图标（因图标较多，可能会卡一小会）
            </Button>
          )}
        </div>
      }
      title={
        <>
          <Radio.Group
            value={iconStyle}
            onChange={(e) => setIconStyle(e.target.value)}
            style={{margin: '8px'}}
          >
            <Radio.Button value="outlined">线框风格</Radio.Button>
            <Radio.Button value="filled">实底风格</Radio.Button>
            <Radio.Button value="twoTone">双色风格</Radio.Button>
          </Radio.Group>
          <Input
            prefix={<SearchOutlined/>}
            placeholder="输入英文关键词进行搜索"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
          />
        </>
      }
      trigger="click"
      open={visible}
      onOpenChange={setVisible}
    >
      <Button>选择图标</Button>
    </Popover>
  );
};

export default IconSelect;
