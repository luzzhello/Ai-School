package com.cxk.template.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import com.cxk.template.mapper.CoursesMapper;
import com.cxk.template.domain.entity.CoursesEntity;
import com.cxk.template.domain.vo.CoursesVO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cn.hutool.core.collection.CollectionUtil;
import java.math.BigDecimal;

import jakarta.annotation.Resource;
import java.util.List;
import com.cxk.template.common.model.PageResult;
import org.apache.commons.lang3.StringUtils;



/**
 * 课程表Service实现类
 *
 * @author 校园小助手 2026/06/03
 */
@Slf4j
@Service
@Transactional(rollbackFor = Throwable.class)
public class CoursesService extends ServiceImpl<CoursesMapper, CoursesEntity>{

    @Resource
    private CoursesMapper coursesMapper;

    /**
     * 新增课程表
     */
    public void saveCourses(CoursesEntity coursesEntity) {
        save(coursesEntity);
    }

    /**
    * 删除课程表
    */
    public void removeCoursess(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return;
        }
        removeByIds(ids);
    }

    /**
    * 修改课程表
    */
    public void updateCourses(CoursesEntity coursesEntity) {
        updateById(coursesEntity);
    }


    /**
     * 根据ID查询课程表
     */
    public CoursesEntity getCoursesById(Long id) {
        return getById(id);
    }

    /**
     * 查看所有课程表
     */
    public List<CoursesEntity> getAllCoursess(CoursesVO coursesVO) {
        List<CoursesEntity> coursesEntityList =lambdaQuery().list();
        return coursesEntityList;
    }

    /**
     * 分页查询课程表
     */
    public PageResult<CoursesEntity> getCoursesByPage(CoursesVO coursesVO) {
            Long id = coursesVO.getId();
            String courseName = coursesVO.getCourseName();
            Long credits = coursesVO.getCredits();
            Page<CoursesEntity> page = lambdaQuery()
                .eq(id != null, CoursesEntity::getId, id)
                .eq(courseName != null, CoursesEntity::getCourseName, courseName)
                .eq(credits != null, CoursesEntity::getCredits, credits)
        .page(coursesVO.toPage());

        PageResult<CoursesEntity> pageResult = PageResult.convert2PageResult(page, page.getRecords());
        return pageResult;
    }
}
