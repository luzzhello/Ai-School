import {theme} from 'antd';
import {css} from '@emotion/css';

export default () => {
  const { token } = theme.useToken();
  const styles = {
    baseView: css`
      display: flex;
      padding-top: 12px;
      @media screen and (max-width: ${token.screenXL}px) {
        flex-direction: column-reverse;
      }
    `,
    left: css`
      min-width: 310px;
      max-width: 600px;
      @media screen and (max-width: ${token.screenXL}px) {
        max-width: 100%;
        padding: 0;
      }
    `,
    right: css`
      width: 360px;
      margin-left: 24px;
      @media screen and (max-width: ${token.screenXL}px) {
        width: 100%;
        margin-left: 0;
        margin-bottom: 24px;
      }
    `,
    phone_number: css`
      width: 100%;
    `,
    avatar: css`
      margin-bottom: 12px;
      text-align: center;
    `,
    avatar_title: css`
      color: ${token.colorTextSecondary};
      font-size: ${token.fontSize};
      margin-top: 8px;
    `,
  };
  return {
    styles,
  };
};
