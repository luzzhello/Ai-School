import React, {useEffect, useState} from "react";
import {PlusOutlined} from "@ant-design/icons";
import {message, Upload} from "antd";
import {upload} from "@/services/template-api/fileController";
import {UploadListType} from "antd/es/upload/interface";

export interface UploadImageProps {
  onUpload?: (url: string) => void;
  listType?: UploadListType
  imageUrl?: string;
  width?: number;
  height?: number;
}

export const UploadImage: React.FC<UploadImageProps> = ({
                                                          onUpload,
                                                          imageUrl,
                                                          listType = 'picture-card' as UploadListType,
                                                          width = 200,
                                                          height = 200,
                                                        }) => {

  const [fileList, setFileList] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // 处理URL，确保前端能正确加载图片
  const processImageUrl = (url: string) => {
    if (!url) return '';
    
    // 输出调试信息
    console.log('原始图片URL:', url);
    
    // 如果是相对URL，确保通过前端代理访问
    if (url.startsWith('/template/files/')) {
      // 前端代理已配置，直接使用相对路径访问
      console.log('处理后的URL:', url);
      return url;
    }
    
    // 如果不是以/template/files/开头，但包含files目录的URL，尝试修复
    if (url.includes('/files/')) {
      // 添加上下文路径
      const fixedUrl = url.startsWith('/') ? '/template' + url : '/template/' + url;
      console.log('修复后的URL:', fixedUrl);
      return fixedUrl;
    }
    
    console.log('未处理的URL:', url);
    return url;
  };

  useEffect(() => {
    if (imageUrl) {
      const processedUrl = processImageUrl(imageUrl);
      setFileList([{
        uid: '1',
        name: 'image',
        status: 'done',
        url: processedUrl
      }]);
    } else {
      setFileList([]);
    }
  }, [imageUrl]);

  const customUpload = async (options: any) => {
    const { file, onSuccess, onError } = options;
    setLoading(true);
    
    try {
      const res = await upload({}, file);
      if (res.code === 0 && res.data) {
        const fileUrl = res.data;
        const processedUrl = processImageUrl(fileUrl);
        
        const fileObj = {
          uid: file.uid || '1',
          name: file.name || 'image',
          status: 'done',
          url: processedUrl
        };
        
        setFileList([fileObj]);
        if (onUpload) {
          onUpload(fileUrl); // 返回原始URL给表单，但显示处理后的URL
        }
        onSuccess(res, file);
        message.success('上传成功');
      } else {
        onError(new Error('上传失败'));
        message.error('上传失败');
      }
    } catch (error) {
      onError(error);
      message.error('上传出错');
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = () => {
    setFileList([]);
    if (onUpload) {
      onUpload('');
    }
    return true;
  };

  // 自定义上传按钮样式
  const uploadButton = (
    <div style={{ 
      width, 
      height, 
      display: 'flex', 
      flexDirection: 'column', 
      justifyContent: 'center', 
      alignItems: 'center',
      border: '1px dashed #d9d9d9',
      borderRadius: '8px',
      background: '#fafafa',
      cursor: 'pointer'
    }}>
      {loading ? (
        <div style={{ padding: '20px 0' }}>上传中...</div>
      ) : (
        <>
          <PlusOutlined style={{ fontSize: 24, marginBottom: 8, color: '#1677ff' }} />
          <div style={{ marginTop: 8, fontSize: 16, color: '#666' }}>点击上传</div>
        </>
      )}
    </div>
  );

  // 自定义图片显示样式
  const imageStyle = {
    width,
    height,
    objectFit: 'cover' as const,
    borderRadius: '4px',
  };

  return (
    <div className="custom-upload-container">
      <style>
        {`
          .custom-upload-container .ant-upload-list-item {
            padding: 0 !important;
            border: none !important;
            margin: 0 !important;
          }
          .custom-upload-container .ant-upload-select {
            margin: 0 !important;
            width: ${width}px !important;
            height: ${height}px !important;
          }
          .custom-upload-container .ant-upload-list-item-thumbnail {
            width: 100% !important;
            height: 100% !important;
          }
        `}
      </style>
      <Upload
        listType={listType}
        fileList={fileList}
        maxCount={1}
        customRequest={customUpload}
        onRemove={handleRemove}
        accept="image/*"
        showUploadList={{
          showPreviewIcon: true,
          showRemoveIcon: true,
        }}
        itemRender={(originNode, file) => {
          // 修改显示的图片尺寸
          if (file.status === 'done' && file.url) {
            return (
              <div style={{ 
                width, 
                height, 
                position: 'relative', 
                overflow: 'hidden',
                borderRadius: '8px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
              }}>
                <img src={file.url} alt={file.name} style={imageStyle} />
                <div 
                  style={{ 
                    position: 'absolute', 
                    top: 0, 
                    right: 0, 
                    padding: '8px', 
                    background: 'rgba(0,0,0,0.5)',
                    borderRadius: '0 0 0 8px'
                  }}
                >
                  <a 
                    onClick={handleRemove} 
                    style={{ color: '#fff', fontSize: '14px' }}
                  >
                    删除
                  </a>
                </div>
              </div>
            );
          }
          return originNode;
        }}
      >
        {fileList.length >= 1 ? null : uploadButton}
      </Upload>
    </div>
  );
};
