package com.cxk.template.common.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 删除请求
 *
 */
@Data
public class IdListForm implements Serializable {

    /**
     * id列表，支持批量删除
     */
    private List<Long> ids;

    private static final long serialVersionUID = 1L;
}

