export const routes = [
  {path: '/', redirect: '/welcome'},
  {path: '*', layout: false, component: './Public/404'},
  {
    path: '/user',
    layout: false,
    routes: [
      {name: '登录', path: '/user/login', component: './Public/Login'},
    ],
  },
  {
    path: '/welcome',
    name: '首页',
    icon: 'smile',
    component: './Public/Welcome'
  },
  {
    path: '/user',
    name: '用户模块',
    icon: 'user',
    routes: [
      {
        name: '用户管理',
        icon: 'user',
        component: './User/UserManager',
        path: '/user/manager',
      }
    ]
  },

  {
    name: '个人中心',
    icon: 'user',
    path: '/account',
    routes: [
      {path: '/account', redirect: '/account/center',},
      {name: '个人设置', path: '/account/settings', component: './Account/Settings',},
    ],
  }
,
  {
    name: "课程表管理",
    icon: 'user',
    path: '/courses',
    component: './Courses',
  },
  {
    name: "选课表管理",
    icon: 'user',
    path: '/enrollments',
    component: './Enrollments',
  },
  {
    name: "学生表管理",
    icon: 'user',
    path: '/students',
    component: './Students',
  },
];


