﻿import {message} from 'antd';
import {history} from "@umijs/max";

// 错误处理方案： 错误类型
enum CodeType {
  SUCCESS = 0,
  NOT_LOGIN = 11002,
}

// 与后端约定的响应数据格式
interface BaseResponse<T> {
  code: number;
  data: T;
  message?: string;
}

interface ResponseStructure {
  config?: any;
  data: any;
  headers?: any;
  status: number;
  statusText?: string;
}

/**
 * @name 错误处理
 * pro 自带的错误处理， 可以在这里做自己的改动
 * @doc https://umijs.org/docs/max/request#配置
 */
export const requestConfig = {
  baseURL: "/api", //反向代理
  withCredentials: true,
  requestInterceptors: [
    (config) => {
      // 拦截请求配置，进行个性化处理。
      const token = localStorage.getItem("token")
      if (token) {
        //如果token存在，就在请求头中添加token
        config.headers.Authorization = `Bearer ${token}`
      }
      const url = config?.url;
      return {...config, url};
    },
  ],

  // 响应拦截器
  responseInterceptors: [
    (response: ResponseStructure) => {
      // 拦截响应数据，进行个性化处理 response:
      const respData: BaseResponse<any> = response.data
      const {code, data} = respData
      const msg = respData.message
      if (code === CodeType.NOT_LOGIN) {
        // 如果未登录，跳转到登录页面
        message.error('未登录，请先登录')
        history.push('/user/login')
        return Promise.reject(msg)
      }
      if (code !== CodeType.SUCCESS) {
        // 如果请求失败，给出错误提示
        if (msg) {
          message.error(msg)
        }
      }
      return response;
    },
  ],
};
