package com.cxk.template.common.config;

import cn.dev33.satoken.interceptor.SaInterceptor;
import cn.dev33.satoken.router.SaRouter;
import cn.dev33.satoken.stp.StpInterface;
import cn.dev33.satoken.stp.StpUtil;
import com.cxk.template.domain.entity.UserEntity;
import com.cxk.template.service.UserService;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Configuration
@Slf4j
public class SaTokenConfig implements WebMvcConfigurer, StpInterface {
    public static List<String> WHITE_LIST = new ArrayList<>();
    public AntPathMatcher antPathMatcher = new AntPathMatcher();

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Resource
    private UserService userService;

    static {
        WHITE_LIST.add("/error");

        // 添加swagger相关的路径
        WHITE_LIST.add("/v3/**");
        WHITE_LIST.add("/swagger-ui.html");
        WHITE_LIST.add("/swagger-ui/**");
        WHITE_LIST.add("/swagger-resources/**");
        WHITE_LIST.add("/webjars/**");
        WHITE_LIST.add("/doc.html");
        WHITE_LIST.add("/doc.html/**");
    }


    @Override
    public List<String> getPermissionList(Object loginId, String loginType) {
        Long loginUserId = Long.parseLong(loginId.toString());
        return new ArrayList<>();
    }

    @Override
    public List<String> getRoleList(Object loginId, String loginType) {
        // 根据用户 id 获取角色列表
        UserEntity currentUser = userService.getCurrentUser();
        String userRole = currentUser.getUserRole();
        return Collections.singletonList(userRole);
    }


    // 注册Sa-Token的拦截器
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 注册路由拦截器，自定义验证规则
        registry.addInterceptor(new SaInterceptor(handler -> {
                    // 获取请求地址
                    ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
                    HttpServletRequest request = attributes.getRequest();
                    String requestURI = request.getRequestURI();
                    // 判断是否为公共接口
                    requestURI = StringUtils.substring(requestURI, contextPath.length(), requestURI.length());  // 去除contextPath
                    if (isPublicURI(requestURI)) {
                        return;
                    }
                    // 登录验证 -- 拦截所有路由，
                    SaRouter.match("/**", StpUtil::checkLogin);
                }))
                .excludePathPatterns()
                .addPathPatterns("/**");
    }

    /**
     * 判断是不是公共方法，可以未登录访问的
     * 例如 /user/public/** /config/public/**
     *
     * @param requestURI
     */
    private boolean isPublicURI(String requestURI) {
        String[] split = requestURI.split("/");
        boolean flag = split.length > 2 && "public".equals(split[2]);
        if (flag) {
            return true;
        }
        // 任何一个匹配WHITE_LIST中的路径都是公共路径
        return WHITE_LIST.stream().anyMatch(uri -> antPathMatcher.match(uri, requestURI));
    }


}
