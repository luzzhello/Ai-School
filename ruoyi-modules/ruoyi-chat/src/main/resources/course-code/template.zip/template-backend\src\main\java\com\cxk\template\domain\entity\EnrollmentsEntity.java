package com.cxk.template.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;
import lombok.EqualsAndHashCode;
import java.util.Date;

/**
 * 选课表实体类
 * <p>请不要手动修改该类</p>
 *
 * @author 校园小助手 2026/06/03
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
@TableName("Enrollments")
public class EnrollmentsEntity extends Model<EnrollmentsEntity> {

    /**
     * 关联学生
     */
    @TableField("student_id")
    private Long studentId;

    /**
     * 关联课程
     */
    @TableId(value ="course_id", type = IdType.ASSIGN_ID)
    private Long courseId;

    /**
     * 注册日期
     */
    @TableField("enrollment_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date enrollmentDate;

}
