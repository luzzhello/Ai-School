import {PlusOutlined} from '@ant-design/icons';
import type {ActionType, ProColumns} from '@ant-design/pro-components';
import {PageContainer, ProTable} from '@ant-design/pro-components';
import '@umijs/max';
import {Button, message, Modal, Space, Typography} from 'antd';
import React, {useRef, useState, useEffect} from 'react';
import {UploadImage} from "@/components/UploadImage";
import {saveCourses, removeCoursess, getCoursesByPage, updateCourses} from "@/services/template-api/coursesController";

/**
 * CoursesEntity管理页面
 *
 * @constructor
 */
const CoursesEntityPage: React.FC = () => {
    // 是否显示新建窗口
    const [modalVisible, setModalVisible] = useState<boolean>(false);
    // 是否显示修改窗口
    const [UpdateModalVisible, setUpdateModalVisible] = useState<boolean>(false);
    //  表格操作
    const actionRef = useRef<ActionType>();
    // 当前CoursesEntity点击的数据
    const [currentRow, setCurrentRow] = useState<API.CoursesEntity | undefined>();


    /**
     * 删除节点
     *
     * @param row
     */
    const handleDelete = async (row: API.CoursesEntity) => {
        const hide = message.loading('正在删除');
        if (!row) return ;
        try {
            Modal.confirm({
                title: '删除课程表',
                content: '确定删除该课程表吗？',
                okText: '确认',
                cancelText: '取消',
                onOk: async () => {
                    await removeCoursess({
                        ids: [row.id],
                    } as API.IdListForm);
                    message.success('删除成功');
                    actionRef?.current?.reload();
                },
            })

        } catch (error: any) {
            message.error('删除失败请重试！');
        }
        hide();
    };

    /**
     * 添加节点
     * @param fields
     */
    const handleSubmit = async (fields: API.CoursesEntity) => {
        const hide = message.loading(currentRow ? '正在更新' : '正在添加');
        try {
            if (currentRow?.id) {
                await updateCourses({
                    ...fields,
                        id: currentRow.id,
                });
            } else {
                await saveCourses(fields);
            }
            hide();
            message.success(currentRow ? '更新成功' : '添加成功');
            setModalVisible(false);
            setCurrentRow(undefined);
            actionRef.current?.reload();
        } catch (error: any) {
            message.error((currentRow ? '更新' : '创建') + '失败：' + error.message);
        }
        hide();
    };

    /**
     * 表格列配置
     */
    const columns: ProColumns<API.CoursesEntity>[] = [
            {
                title: '课程ID',
                dataIndex: 'id',
                    valueType: 'digit',
                    hideInForm: true,
                    hideInSearch: true,
            },
            {
                title: '课程名',
                dataIndex: 'courseName',
                    valueType: 'text',
            },
            {
                title: '学分',
                dataIndex: 'credits',
                    valueType: 'digit',
            },
        {
            title: '操作',
            dataIndex: 'option',
            valueType: 'option',
            render: (_, record) => (
                <Space size="middle">
                    <Typography.Link
                        onClick={() => {
                            setCurrentRow(record);
                            setUpdateModalVisible(true);
                        }}
                    >
                        修改
                    </Typography.Link>
                    <Typography.Link type="danger" onClick={() => handleDelete(record)}>
                        删除
                    </Typography.Link>
                </Space>
            ),
        },
    ];

    /**
     * 创建弹窗
     * @constructor
     */
    const CreateOrUpdateModal: React.FC = () => {
        return (
            <Modal
                destroyOnClose
                title={currentRow ? '修改' : '新建'}
                open={modalVisible}
                footer={null}
                onCancel={() => {
                    setModalVisible(false);
                    setCurrentRow(undefined);
                }}
            >
                <ProTable
                    type="form"
                    columns={columns}
                    form={{
                        initialValues: currentRow,
                    }}
                    onSubmit={handleSubmit}
                />
            </Modal>
        );
    };

    /**
     * 修改弹窗
     * @constructor
     */
    const UpdateModal: React.FC = () => {
        return (
            <Modal
                destroyOnClose
                title="修改课程表"
                open={UpdateModalVisible}
                footer={null}
                onCancel={() => {
                    setUpdateModalVisible(false);
                    setCurrentRow(undefined);
                }}
            >
                <ProTable
                    type="form"
                    columns={columns}
                    form={{
                        initialValues: currentRow,
                    }}
                    onSubmit={async (fields) => {
                        const hide = message.loading('正在更新');
                        try {
                            await updateCourses({
                                ...fields,
                                    id: currentRow?.id,
                            });
                            hide();
                            message.success('更新成功');
                            setUpdateModalVisible(false);
                            setCurrentRow(undefined);
                            actionRef.current?.reload();
                        } catch (error: any) {
                            hide();
                            message.error('更新失败：' + error.message);
                        }
                    }}
                />
            </Modal>
        );
    };

    return (
        <PageContainer>
            <ProTable<API.CoursesEntity>
                headerTitle={'课程表管理'}
                actionRef={actionRef}
                rowKey="key"
                search={{
                    labelWidth: 120,
                }}
                toolBarRender={() => [
                    <Button
                        type="primary"
                        key="primary"
                        onClick={() => {
                            setCurrentRow(undefined);
                            setModalVisible(true);
                        }}
                    >
                        <PlusOutlined/> 新建
                    </Button>,
                ]}
                request={async (params, sort, filter) => {
                    const sortField = Object.keys(sort)?.[0];
                    const sortOrder = sort?.[sortField] ?? undefined;
                    const {data, code} = await getCoursesByPage({
                        pageSize: params.pageSize,
                        pageNumber: params.current,
                        ...params,
                        sortField,
                        sortOrder,
                        ...filter,
                    } as API.CoursesVO);
                    return {
                        success: code === 0,
                        data: data.records || [],
                        total: Number(data?.total) || 0,
                    };
                }}
                pagination={{
                    showSizeChanger: true,
                } as any}
                columns={columns}
            />
            <CreateOrUpdateModal/>
            <UpdateModal/>
        </PageContainer>
    );
};
export default CoursesEntityPage;
