const MENU_TYPE_ENUM = {
  CATALOG: {
    value: 1,
    desc: '目录',
  },
  MENU: {
    value: 2,
    desc: '菜单',
  },
  POINTS: {
    value: 3,
    desc: '按钮',
  },
};


const USER_ROLE_ENUM = {
  ADMIN: {
    value: 1,
    desc: '管理员',
  },
  USER: {
    value: 2,
    desc: '用户',
  },
  GUEST: {
    value: 3,
    desc: '游客',
  },
  BAN: {
    value: 4,
    desc: '禁用',
  },
};

export {
  MENU_TYPE_ENUM,
  USER_ROLE_ENUM
}
