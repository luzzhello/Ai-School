package com.cxk.template.common.model;

/**
 * 角色常量
 */
public interface RoleConstant {
    /**
     * 管理员
     */
    String ADMIN = "admin";

    /**
     * 普通用户
     */
    String USER = "user";
    /**
     * 禁用
     */
    String BAN = "ban";
}
