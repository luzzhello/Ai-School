package com.cxk.template.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 用户实体类
 * <p>请不要手动修改该类</p>
 */
@Data
@TableName("tb_user")
@Schema(description = "用户实体类")
public class UserEntity implements Serializable {

    @Schema(description = "id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "账号")
    @TableField("userAccount")
    private String userAccount;

    @Schema(description = "密码")
    @TableField("userPassword")
    private String userPassword;

    @Schema(description = "用户昵称")
    @TableField("userName")
    private String userName;

    @Schema(description = "用户头像")
    @TableField("userAvatar")
    private String userAvatar;

    @Schema(description = "用户简介")
    @TableField("userProfile")
    private String userProfile;

    @Schema(description = "用户角色")
    @TableField("userRole")
    private String userRole;
    @TableField("createTime")
    private LocalDateTime createTime;
    @TableField(value = "updateTime")
    private LocalDateTime updateTime;
}
