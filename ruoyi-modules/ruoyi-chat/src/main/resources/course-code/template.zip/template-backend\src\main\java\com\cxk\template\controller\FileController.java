package com.cxk.template.controller;

import com.cxk.template.common.config.FileStorageConfig;
import com.cxk.template.common.exception.BusinessException;
import com.cxk.template.common.model.Result;
import com.cxk.template.common.utils.FileStorageUtils;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * 文件上传控制器
 */
@RestController
@RequestMapping("/file")
@Slf4j
public class FileController {

    @Resource
    private FileStorageUtils fileStorageUtils;

    @Resource
    private FileStorageConfig fileStorageConfig;

    /**
     * 上传文件
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<String> upload(@RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return Result.error("上传文件不能为空");
            }

            // 获取原始文件名
            String fileName = file.getOriginalFilename();
            if (StringUtils.isBlank(fileName)) {
                fileName = System.currentTimeMillis() + ".tmp";
            }

            // 上传文件并获取存储的文件名
            String storedFileName = fileStorageUtils.uploadFile(file);
            if (storedFileName == null) {
                throw new BusinessException("文件上传失败");
            }

            // 生成访问URL
            String url = fileStorageUtils.getObjectUrl(storedFileName);
            return Result.success(url);
        } catch (Exception e) {
            log.error("上传文件失败", e);
            throw new BusinessException("上传文件失败: " + e.getMessage());
        }
    }

    /**
     * 获取文件URL
     */
    @GetMapping("/url/{fileName}")
    public Result<String> getFileUrl(@PathVariable String fileName) {
        try {
            if (StringUtils.isBlank(fileName)) {
                return Result.error("文件名不能为空");
            }
            String url = fileStorageUtils.getObjectUrl(fileName);
            return Result.success(url);
        } catch (Exception e) {
            log.error("获取文件URL失败", e);
            throw new BusinessException("获取文件URL失败: " + e.getMessage());
        }
    }

    /**
     * 获取文件列表
     */
    @GetMapping("/list")
    public Result<List<String>> listFiles() {
        try {
            List<String> fileList = fileStorageUtils.listObjects();
            return Result.success(fileList);
        } catch (Exception e) {
            log.error("获取文件列表失败", e);
            throw new BusinessException("获取文件列表失败: " + e.getMessage());
        }
    }

    /**
     * 删除文件
     */
    @DeleteMapping("/{fileName}")
    public Result<Void> deleteFile(@PathVariable String fileName) {
        try {
            if (StringUtils.isBlank(fileName)) {
                return Result.error("文件名不能为空");
            }
            fileStorageUtils.deleteObject(fileName);
            return Result.success();
        } catch (Exception e) {
            log.error("删除文件失败", e);
            throw new BusinessException("删除文件失败: " + e.getMessage());
        }
    }

    /**
     * 测试端点 - 获取上传路径信息
     */
    @GetMapping("/storage-info")
    public Result<String> getStorageInfo() {
        try {
            String uploadDir = fileStorageConfig.getUploadDir();
            String baseUrl = fileStorageConfig.getBaseUrl();
            String absolutePath = Paths.get(uploadDir).toAbsolutePath().toString();

            String info = String.format(
                    "Storage Configuration:\n" +
                            "Upload Directory: %s\n" +
                            "Absolute Path: %s\n" +
                            "Base URL: %s\n" +
                            "Directory exists: %s",
                    uploadDir, absolutePath, baseUrl,
                    Files.exists(Paths.get(uploadDir)) ? "Yes" : "No");

            return Result.success(info);
        } catch (Exception e) {
            log.error("获取存储信息失败", e);
            throw new BusinessException("获取存储信息失败: " + e.getMessage());
        }
    }
}
