import {List, message, Modal} from 'antd';
import React, {useState} from 'react';
import {history, useModel} from "@umijs/max";

type Unpacked<T> = T extends (infer U)[] ? U : T;

const SecurityView: React.FC = () => {
  const [isResetPasswordOpen, setResetPasswordOpen] = useState(false);
  const [isResetPasswordConfirmLoading, setResetPasswordConfirmLoading] = useState(false);

  const {initialState, setInitialState} = useModel('@@initialState');
  const handleResetOk = async () => {
    setResetPasswordConfirmLoading(true);
    const email = initialState?.currentUser?.userEmail
    // const res = await requestResetLink({email: email})
    const res = {code: 0}
    if (res.code === 0) {
      message.success("重置密码邮件已发送，请注意查收")
    }
    setResetPasswordConfirmLoading(false);
    setResetPasswordOpen(false);
  };

  const handleResetCancel = () => {
    setResetPasswordOpen(false);
  };

  const getData = () => [
    {
      title: '账户密码',
      description: (
        <>
          设置更高强度的密码，让账号更安全
        </>
      ),
      actions: [<a onClick={() => {
        history.push(`/account/changePassword`);
      }}>修改</a>],
    },
    {
      title: '重置密码',
      description: (
        <>
          忘记/不知道当前账户的密码？通过重置密码来设置密码吧！
        </>
      ),
      actions: [<a onClick={() => {
        setResetPasswordOpen(true)
      }}>重置</a>],
    }
    // {
    //   title: '密保手机',
    //   description: `已绑定手机：138****8293`,
    //   actions: [<a key="Modify">修改</a>],
    // },
    // {
    //   title: '密保问题',
    //   description: '未设置密保问题，密保问题可有效保护账户安全',
    //   actions: [<a key="Set">设置</a>],
    // },
    // {
    //   title: '备用邮箱',
    //   description: `已绑定邮箱：ant***sign.com`,
    //   actions: [<a key="Modify">修改</a>],
    // },
    // {
    //   title: 'MFA 设备',
    //   description: '未绑定 MFA 设备，绑定后，可以进行二次确认',
    //   actions: [<a key="bind">绑定</a>],
    // },
  ];

  const data = getData();
  return (
    <>
      <List<Unpacked<typeof data>>
        itemLayout="horizontal"
        dataSource={data}
        renderItem={(item) => (
          <List.Item actions={item.actions}>
            <List.Item.Meta title={item.title} description={item.description}/>
          </List.Item>
        )}
      />
      <Modal title="重置密码" open={isResetPasswordOpen} onOk={handleResetOk} onCancel={handleResetCancel}
             confirmLoading={isResetPasswordConfirmLoading}>
        <p>我们将会发送一份重置密码的邮件到你注册该账号的邮箱，点击邮箱内链接进行重置密码流程</p>
      </Modal>
    </>
  );
};

export default SecurityView;
