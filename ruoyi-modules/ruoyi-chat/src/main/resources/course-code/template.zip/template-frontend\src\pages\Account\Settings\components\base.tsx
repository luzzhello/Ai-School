import {ProForm, ProFormInstance, ProFormText, ProFormTextArea} from '@ant-design/pro-components';
import {Avatar, Card, Col, Divider, message, Row, Typography, Image} from 'antd';
import React, {useEffect, useRef, useState} from 'react';
import {getCurrentUser, updateUser} from "@/services/template-api/userController";
import {UploadImage} from "@/components";
import {UserOutlined} from '@ant-design/icons';

const BaseView: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const formRef = useRef<ProFormInstance>();

  // 初始化时加载用户信息
  useEffect(() => {
    fetchUserInfo();
  }, []);

  // 获取用户信息
  const fetchUserInfo = async () => {
    try {
      const res = await getCurrentUser();
      if (res.code === 0 && res.data) {
        setUser(res.data);
      }
    } catch (error) {
      console.error('获取用户信息失败:', error);
      message.error('获取用户信息失败');
    }
  };

  // 更新用户头像
  const handleAvatarUpdate = async (url: string) => {
    if (!user?.id) {
      message.error('获取用户信息失败');
      return;
    }

    try {
      const res = await updateUser({
        id: user.id,
        userAvatar: url
      });

      if (res.code === 0) {
        message.success('头像更新成功');
        // 刷新用户信息
        fetchUserInfo();
      } else {
        message.error(res.message || '头像更新失败');
      }
    } catch (error) {
      message.error('头像更新失败');
      console.error('头像更新错误:', error);
    }
  };

  return (
    <div style={{ background: '#f5f5f5', padding: '24px', borderRadius: '8px' }}>
      <Row gutter={24}>
        <Col xs={24} sm={24} md={8} style={{ marginBottom: '24px' }}>
          <Card
            bordered={false}
            style={{ height: '100%', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
          >
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <div style={{ marginBottom: '24px' }}>
                {user?.userAvatar ? (
                  <Image
                    src={user.userAvatar}
                    width={120}
                    height={120}
                    style={{ borderRadius: '50%', cursor: 'pointer' }}
                    preview={{
                      mask: '点击查看大图',
                      maskClassName: 'custom-mask'
                    }}
                  />
                ) : (
                  <Avatar size={120} icon={<UserOutlined />} />
                )}
              </div>
              <Typography.Title level={4} style={{ marginBottom: '4px' }}>
                {user?.userName || '未设置昵称'}
              </Typography.Title>
              <Typography.Text type="secondary">
                {user?.userRole === 'admin' ? '管理员' : '普通用户'}
              </Typography.Text>
              <Divider style={{ margin: '16px 0' }} />
              <Typography.Paragraph
                ellipsis={{ rows: 3, expandable: true, symbol: '更多' }}
                style={{ textAlign: 'left' }}
              >
                {user?.userProfile || '这个人很懒，还没有填写个人简介...'}
              </Typography.Paragraph>
            </div>
          </Card>
        </Col>

        <Col xs={24} sm={24} md={16}>
          <Card
            title={
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ fontSize: '18px', fontWeight: 'bold' }}>个人资料设置</span>
              </div>
            }
            bordered={false}
            style={{ borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
          >
            <Row gutter={24}>
              <Col xs={24} md={12}>
                <ProForm
                  layout="vertical"
                  onFinish={async (values) => {
                    if (!user?.id) {
                      message.error('获取用户信息失败');
                      return false;
                    }

                    const updateData = {
                      ...values,
                      id: user.id
                    };

                    try {
                      const res = await updateUser(updateData);
                      if (res.code === 0) {
                        message.success('更新个人资料成功');
                        // 刷新用户信息
                        fetchUserInfo();
                        return true;
                      } else {
                        message.error(res.message || '更新失败');
                      }
                    } catch (error) {
                      console.error('更新用户信息失败:', error);
                      message.error('更新失败');
                    }
                    return false;
                  }}
                  submitter={{
                    searchConfig: {
                      submitText: '保存修改',
                    },
                    submitButtonProps: {
                      type: 'primary',
                      size: 'large',
                      block: true,
                      style: { marginTop: '24px' }
                    },
                  }}
                  initialValues={user || {}}
                  formRef={formRef}
                  requiredMark={false}
                >
                  <ProFormText
                    name="userName"
                    label="昵称"
                    fieldProps={{
                      size: 'large',
                    }}
                    rules={[
                      {
                        required: true,
                        message: '请输入您的昵称',
                      },
                    ]}
                    placeholder="请输入您的昵称"
                  />
                  <ProFormTextArea
                    name="userProfile"
                    label="个人简介"
                    fieldProps={{
                      size: 'large',
                      rows: 4,
                    }}
                    rules={[
                      {
                        required: true,
                        message: '请输入个人简介',
                      },
                    ]}
                    placeholder="介绍一下自己吧"
                  />
                </ProForm>
              </Col>
              <Col xs={24} md={12}>
                <div style={{ paddingTop: '28px', textAlign: 'center' }}>
                  <Typography.Title level={5} style={{ marginBottom: '16px' }}>头像设置</Typography.Title>
                  <div style={{ margin: '0 auto', maxWidth: '280px' }}>
                    <UploadImage
                      imageUrl={user?.userAvatar}
                      onUpload={handleAvatarUpdate}
                      width={220}
                      height={220}
                    />
                  </div>
                </div>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default BaseView;
