package com.cxk.template.service;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cxk.template.common.exception.ThrowUtils;
import com.cxk.template.common.model.IdListForm;
import com.cxk.template.common.model.PageResult;
import com.cxk.template.domain.entity.UserEntity;
import com.cxk.template.domain.vo.UserVO;
import com.cxk.template.mapper.UserMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserService extends ServiceImpl<UserMapper, UserEntity> {
    /**
     * 保存用户
     */
    public Long saveUser(UserEntity userEntity) {
        save(userEntity);
        return userEntity.getId();
    }

    /**
     * 批量删除用户
     */
    public Boolean removeUsers(IdListForm idList) {
        if (CollectionUtil.isEmpty(idList.getIds())) {
            return true;
        }
        List<Long> ids = idList.getIds();
        removeByIds(ids);
        return true;
    }

    /**
     * 更新用户数据
     */
    public Boolean updateUser(UserEntity userEntity) {
        updateById(userEntity);
        return true;
    }

    /**
     * 根据id查询用户
     */
    public UserEntity getUserById(Long userId) {
        UserEntity user = getById(userId);
        return user;
    }


    public Boolean register(UserVO request) {
        String userAccount = request.getUserAccount();
        String userPassword = request.getUserPassword();
        UserEntity user = lambdaQuery().eq(UserEntity::getUserAccount, userAccount).one();
        ThrowUtils.throwIf(user != null, "账号已注册");
        UserEntity userEntity = new UserEntity();
        userEntity.setUserAccount(userAccount);
        userEntity.setUserPassword(userPassword);
        // 随机生成用户名字符串，不要数字
        userEntity.setUserName(RandomUtil.randomString(6));
        return save(userEntity);
    }


    public UserVO login(UserVO userVO) {
        String userAccount = userVO.getUserAccount();
        String userPassword = userVO.getUserPassword();
        UserEntity user = lambdaQuery().eq(UserEntity::getUserAccount, userAccount).one();
        ThrowUtils.throwIf(user == null, "用户不存在");
        ThrowUtils.throwIf(!user.getUserPassword().equals(userPassword), "密码错误");
        UserVO userInfo = BeanUtil.copyProperties(user, UserVO.class);
        StpUtil.login(user.getId());
        String token = StpUtil.getTokenInfo().getTokenValue();
        userVO.setToken(token);
        return userInfo;
    }


    /**
     * 分页查询用户
     */
    public PageResult<UserEntity> getUserByPage(UserVO userVO) {
        String userAccount = userVO.getUserAccount();
        String userName = userVO.getUserName();
        String userRole = userVO.getUserRole();

        Page<UserEntity> page = lambdaQuery().like(StringUtils.isNotBlank(userAccount), UserEntity::getUserAccount, userAccount).like(StringUtils.isNotBlank(userName), UserEntity::getUserName, userName).like(StringUtils.isNotBlank(userRole), UserEntity::getUserRole, userRole).page(userVO.toPage());
        PageResult<UserEntity> userEntityPageResult = PageResult.convert2PageResult(page, page.getRecords());
        return userEntityPageResult;
    }


    /**
     * 获取当前用户信息
     */
    public UserEntity getCurrentUser() {
        Long userId = StpUtil.getLoginIdAsLong();
        UserEntity userEntity = getById(userId);
        return userEntity;
    }
}
