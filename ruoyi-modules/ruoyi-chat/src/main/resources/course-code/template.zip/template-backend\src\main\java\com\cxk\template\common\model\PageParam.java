package com.cxk.template.common.model;

import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * 分页基础参数
 */
@Data
@Slf4j
public class PageParam {
    @Schema(description = "页码(不能为空)", example = "1")
    @NotNull(message = "分页参数不能为空")
    private Long pageNumber;
    @Schema(description = "每页数量(不能为空)")
    @NotNull(message = "每页数量不能为空")
    @Max(value = 500, message = "每页最大为500")
    private Long pageSize;
    @Schema(description = "排序字段 column 是列，asc=true正序，false倒序")
    private OrderItem orderItem;


    public <T> Page<T> toPage() {
        Page<T> page = new Page<>(pageNumber, pageSize);
        List<OrderItem> orderItemList = new ArrayList<>();
        orderItemList.add(orderItem);
        page.setOrders(orderItemList);
        return page;
    }
}
