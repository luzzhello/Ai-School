import {routes} from "../../config/routes";
import {MENU_TYPE_ENUM} from "@/constants/common-enums";

/**
 * 递归构建菜单树
 * @param menuList  菜单列表
 */
export const buildTree = (menuList: any[]) => {
  if (!menuList) {
    return [];
  }
  return menuList.map((item: any) => {
    const children = buildTree(item.children)
    return {
      ...item,
      title: item.menuName,
      key: item.menuId,
      value: item,
      ...(children.length > 0 && {children}) // 如果 children 为空数组，则不添加 children 属性
    }
  })
}


/**
 * 构建添加菜单的菜单树 （不要按钮类型）
 */
export const buildAddMenuTree = (menuList: any[]) => {
  const buildMenuTreeWithoutButton = (menuList: any[]) => {
    if (!menuList) {
      return null;
    }
    return menuList.map((item: any) => {
      const children = buildMenuTreeWithoutButton(item.children)
      if (item.menuType === MENU_TYPE_ENUM.POINTS.value) {
        return null
      } else {
        return {
          ...item,
          title: item.menuName,
          key: item.menuId,
          value: item,
          ...(children && {children}) // 如果 children 为空数组，则不添加 children 属性
        }
      }
    })
  }

  const treeWithoutButton = buildMenuTreeWithoutButton(menuList)

  // 添加一个顶级目录
  const topLevelDirectory = [{
    title: '顶级目录', // 顶级目录的名称
    value: 0, // 设定一个特殊的 value 值，通常可以是 0 或其它标识顶级目录的值
    children: treeWithoutButton // 所有原始菜单作为这个顶级目录的子菜单
  }];
  const tmpData = buildTree(menuList)
  return {tmpData, topLevelDirectory}
}


function findRouteByPath(routes, currentPath) {
  for (const route of routes) {
    // 如果路径完全匹配，返回当前路由
    if (route.path === currentPath) {
      return route;
    }

    // 如果路径是动态路由参数格式
    const dynamicMatch = route.path && route.path.includes('/:');
    if (dynamicMatch) {
      const basePath = route.path.split('/:')[0];
      if (currentPath.startsWith(basePath)) {
        return route;
      }
    }

    // 递归查找子路由
    if (route.routes) {
      const found = findRouteByPath(route.routes, currentPath);
      if (found) {
        return found;
      }
    }
  }
  // 如果没有匹配，返回 undefined 或者根据需求返回 404 路由
  return undefined;
}

export function findRoute(currentPath){
  return findRouteByPath(routes, currentPath);
}
