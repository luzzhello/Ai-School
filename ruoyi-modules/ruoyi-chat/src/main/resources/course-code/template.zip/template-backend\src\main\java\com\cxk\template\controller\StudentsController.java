package com.cxk.template.controller;

import com.cxk.template.domain.entity.StudentsEntity;
import com.cxk.template.service.StudentsService;
import com.cxk.template.domain.vo.StudentsVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
import com.cxk.template.common.model.Result;
import com.cxk.template.common.model.PageResult;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import com.cxk.template.common.model.IdListForm;

/**
 * 学生表Controller层
 *
 * @author 校园小助手 2026/06/03
 */
@Slf4j
@RestController
@RequestMapping("/students")
public class StudentsController {

    @Resource
    private StudentsService studentsService;


    /**
     * 新增学生表
     */
    @PostMapping("/save")
    @Operation(summary = "保存学生表数据}")
    public Result<Void> saveStudents( @RequestBody StudentsEntity studentsEntity) {
        studentsService.saveStudents(studentsEntity);
        return Result.success();
    }

    /**
     * 删除学生表
     */
    @PostMapping("/remove")
    @Operation(summary = "删除学生表数据}")
    public Result<Void> removeStudentss( @RequestBody IdListForm idListForm) {
        List<Long> ids = idListForm.getIds();
        studentsService.removeStudentss(ids);
        return Result.success();
    }

    /**
     * 修改学生表
     */
    @PostMapping("/update")
    @Operation(summary = "修改学生表数据}")
    public Result<Void> updateStudents(@RequestBody StudentsEntity studentsEntity) {
        studentsService.updateStudents(studentsEntity);
        return Result.success();
    }

    /**
      * 根据ID查询学生表
      */
    @GetMapping("/get")
    @Operation(summary = "根据ID查询学生表数据}")
    public Result<StudentsEntity> getStudentsById(@RequestParam Long id) {
        StudentsEntity studentsEntity = studentsService.getStudentsById(id);
        return Result.success(studentsEntity);
    }

    /**
     * 查看所有学生表
     */
    @PostMapping("/getAll")
    @Operation(summary = "查看所有学生表数据}")
    public Result<List<StudentsEntity>> getAllStudentss(@RequestBody StudentsVO studentsVO) {
        List<StudentsEntity> studentsEntityList = studentsService.getAllStudentss(studentsVO);
        return Result.success(studentsEntityList);
    }

    /**
     * 分页查询学生表
     */
    @PostMapping("/getPage")
    @Operation(summary = "分页查询学生表数据}")
    public Result<PageResult<StudentsEntity>> getStudentsByPage( @RequestBody StudentsVO studentsVO) {
        PageResult<StudentsEntity> pageResult = studentsService.getStudentsByPage(studentsVO);
        return Result.success(pageResult);
    }
}
