create database if not exists template;
use template;
create table if not exists tb_user
(
    id           bigint auto_increment comment 'id'
        primary key,
    userAccount  varchar(256)                           null comment '账号',
    userPassword varchar(512)                           null comment '密码',
    userName     varchar(256)                           null comment '用户昵称',
    userAvatar   varchar(1024)                          null comment '用户头像',
    userProfile  varchar(512)                           null comment '用户简介',
    userPhone    varchar(11)                            null comment '手机号',
    userRole     varchar(256) default 'user'            not null comment '用户角色：user/admin/ban',
    inviteCode   varchar(255)                           null comment '邀请码',
    createTime   datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updateTime   datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    deletedFlag  tinyint      default 0                 not null comment '是否删除',
    constraint tb_user_pk
        unique (userAccount)
)
    comment '用户' collate = utf8mb4_unicode_ci;

create table if not exists Students (
    id INT PRIMARY KEY COMMENT '学号',
    name VARCHAR(100) COMMENT '姓名',
    age INT COMMENT '年龄',
    email VARCHAR(100) COMMENT '邮箱'
) COMMENT '学生表';
create table if not exists Courses (
    id INT PRIMARY KEY COMMENT '课程ID',
    course_name VARCHAR(100) COMMENT '课程名',
    credits INT COMMENT '学分'
) COMMENT '课程表';
create table if not exists Enrollments (
    student_id INT COMMENT '关联学生',
    course_id INT COMMENT '关联课程',
    enrollment_date DATE COMMENT '注册日期',
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES Students(id) COMMENT '选修',
    FOREIGN KEY (course_id) REFERENCES Courses(id) COMMENT '开设'
) COMMENT '选课表'