package com.cxk.template.controller;

import cn.dev33.satoken.stp.StpUtil;
import com.cxk.template.common.model.IdListForm;
import com.cxk.template.common.model.PageResult;
import com.cxk.template.common.model.Result;
import com.cxk.template.domain.entity.UserEntity;
import com.cxk.template.domain.vo.UserVO;
import com.cxk.template.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * 用户Controller层
 * 用户接口
 */
@Slf4j
@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    @PostMapping("/save")
    @Operation(summary = "保存用户数据")
    public Result<Long> saveUser(@RequestBody UserEntity userEntity) {
        Long id = userService.saveUser(userEntity);
        return Result.success(id);
    }

    @PostMapping("/remove")
    public Result removeUsers(@RequestBody IdListForm idListForm) {
        userService.removeUsers(idListForm);
        return Result.success();
    }

    @PostMapping("/update")
    @Operation(summary = "更新用户数据 ")
    public Result updateUser(@RequestBody UserEntity userEntity) {
        userEntity.setId(StpUtil.getLoginIdAsLong());
        userService.updateUser(userEntity);
        return Result.success();
    }

    @PostMapping("/getPage")
    @Operation(summary = "分页查询用户数据 ")
    public Result<PageResult<UserEntity>> getUserByPage(@RequestBody UserVO userVO) {
        PageResult<UserEntity> pageResult = userService.getUserByPage(userVO);
        return Result.success(pageResult);
    }

    @GetMapping("/get")
    @Operation(summary = "根据ID查询用户数据 ")
    public Result<UserEntity> getUserById(@RequestParam Long userId) {
        UserEntity user = userService.getUserById(userId);
        return Result.success(user);
    }

    @GetMapping("/current")
    @Operation(summary = "获取当前用户信息 ")
    public Result<UserEntity> getCurrentUser() {
        UserEntity currentUser = userService.getCurrentUser();
        return Result.success(currentUser);
    }


    @PostMapping("/public/register")
    @Operation(summary = "注册")
    public Result<Boolean> register(@RequestBody UserVO userVO) {
        Boolean flag = userService.register(userVO);
        return Result.success(flag);
    }

    @PostMapping("/public/login")
    @Operation(summary = "登录")
    public Result<UserVO> login(@RequestBody UserVO userVO) {
        UserVO token = userService.login(userVO);
        return Result.success(token);
    }


    @GetMapping("/logout")
    @Operation(summary = "退出登录")
    public Result<Boolean> logout() {
        StpUtil.logout();
        return Result.success(true);
    }
}
