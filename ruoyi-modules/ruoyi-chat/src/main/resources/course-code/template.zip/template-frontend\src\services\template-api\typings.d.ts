declare namespace API {
  type deleteFileParams = {
    fileName: string;
  };

  type getFileUrlParams = {
    fileName: string;
  };

  type getUserByIdParams = {
    userId: number;
  };

  type IdListForm = {
    ids?: number[];
  };

  type OrderItem = {
    column?: string;
    asc?: boolean;
  };

  type PageResultUserEntity = {
    /** 当前页 */
    pageNumber?: number;
    /** 每页的数量 */
    pageSize?: number;
    /** 总记录数 */
    total?: number;
    /** 总页数 */
    pages?: number;
    /** 结果集 */
    records?: UserEntity[];
  };

  type Result = {
    code?: number;
    data?: any;
    message?: string;
  };

  type ResultBoolean = {
    code?: number;
    data?: boolean;
    message?: string;
  };

  type ResultListString = {
    code?: number;
    data?: string[];
    message?: string;
  };

  type ResultLong = {
    code?: number;
    data?: number;
    message?: string;
  };

  type ResultPageResultUserEntity = {
    code?: number;
    data?: PageResultUserEntity;
    message?: string;
  };

  type ResultString = {
    code?: number;
    data?: string;
    message?: string;
  };

  type ResultUserEntity = {
    code?: number;
    data?: UserEntity;
    message?: string;
  };

  type ResultUserVO = {
    code?: number;
    data?: UserVO;
    message?: string;
  };

  type ResultVoid = {
    code?: number;
    data?: any;
    message?: string;
  };

  type UserEntity = {
    /** id */
    id?: number;
    /** 账号 */
    userAccount?: string;
    /** 密码 */
    userPassword?: string;
    /** 用户昵称 */
    userName?: string;
    /** 用户头像 */
    userAvatar?: string;
    /** 用户简介 */
    userProfile?: string;
    /** 用户角色 */
    userRole?: string;
    createTime?: string;
    updateTime?: string;
  };

  type UserVO = {
    /** 页码(不能为空) */
    pageNumber: number;
    /** 每页数量(不能为空) */
    pageSize: number;
    /** 排序字段 column 是列，asc=true正序，false倒序 */
    orderItem?: OrderItem;
    /** id */
    id?: number;
    /** 账号 */
    userAccount?: string;
    /** 密码 */
    userPassword?: string;
    /** 用户昵称 */
    userName?: string;
    /** 用户头像 */
    userAvatar?: string;
    /** 用户简介 */
    userProfile?: string;
    /** 创建时间 */
    createTime?: string;
    /** 更新时间 */
    updateTime?: string;
    /** 用户角色 */
    userRole?: string;
    /** token */
    token?: string;
  };
}
